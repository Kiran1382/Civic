import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { readAloud, startVoiceCommand, getEasyViewClasses, handleSmartAudioHelp, addLongPressListener } from '@/lib/accessibility';
import { Button } from '@/components/ui/button';
import {
  Volume2,
  VolumeX,
  MousePointer,
  Eye,
  Mic,
  Home,
  Settings,
  Headphones,
  Speaker
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface AccessibilityLayoutProps {
  children: React.ReactNode;
  title?: string;
}

export const AccessibilityLayout: React.FC<AccessibilityLayoutProps> = ({
  children,
  title = "Civic Engagement App"
}) => {
  const { state, toggleEasyView, toggleTouchToRead, toggleVoiceMode, toggleAudioHelp } = useAccessibility();
  const [showTooltip, setShowTooltip] = useState(false);

  const handleReadTitle = () => {
    readAloud(title);
  };

  const handleAudioHelpToggle = () => {
    toggleAudioHelp();
    setShowTooltip(true);

    // Hide tooltip after 3 seconds
    setTimeout(() => setShowTooltip(false), 3000);

    // Always announce toggle changes (explicit user action)
    const newState = !state.isAudioHelpEnabled;
    if (newState) {
      readAloud('Audio Help is now ON. Tap any button or field to hear it spoken aloud.', true);
    } else {
      readAloud('Audio Help is now OFF.', true);
    }
  };

  const handleReadScreen = () => {
    // Generate intelligent summary based on page title
    let summary = '';

    if (title.includes('Login')) {
      summary = 'This is the login screen. Enter your mobile number to receive an OTP code for secure access to civic services.';
    } else if (title.includes('Dashboard')) {
      summary = 'This is your civic dashboard. Choose from voting help, reporting issues, community events, policy feedback, and voter services.';
    } else if (title.includes('Voting')) {
      summary = 'This screen helps you learn how to vote with step-by-step guidance, sample ballot practice, and polling booth finder.';
    } else if (title.includes('Report')) {
      summary = 'This screen helps you report local community issues like broken roads or public facilities using photos and voice descriptions.';
    } else if (title.includes('Events')) {
      summary = 'This screen shows community events, town halls, and meetings happening near you that you can attend.';
    } else if (title.includes('Policy')) {
      summary = 'This screen lets you provide feedback on local government policies by reading summaries and sharing your opinions.';
    } else if (title.includes('News')) {
      summary = 'This screen shows the latest government news and announcements with voice reading support.';
    } else if (title.includes('Registration')) {
      summary = 'This screen helps you register as a new voter with step-by-step form filling and document upload.';
    } else if (title.includes('Download')) {
      summary = 'This screen helps you download your digital voter ID card with OTP verification.';
    } else if (title.includes('Settings')) {
      summary = 'This screen lets you adjust accessibility settings like voice speed, font size, and contact support for help.';
    } else {
      summary = `This is the ${title} screen. Use the navigation to explore civic engagement features.`;
    }

    readAloud(summary, true); // Force reading since user explicitly clicked
  };

  // Simplified smart audio help - prevent hanging
  useEffect(() => {
    if (!state.isAudioHelpEnabled) return;

    const handleDocumentClick = (event: Event) => {
      const target = event.target as HTMLElement;
      if (!target) return;

      // Only handle buttons and form elements
      if (target.tagName === 'BUTTON' || target.tagName === 'INPUT' || target.tagName === 'SELECT') {
        const text = target.getAttribute('aria-label') ||
                    target.getAttribute('placeholder') ||
                    target.textContent?.trim() ||
                    'Interactive element';

        if (text && text !== 'Interactive element') {
          handleSmartAudioHelp(text, true);
        }
      }
    };

    // Add single document listener instead of multiple element listeners
    document.addEventListener('click', handleDocumentClick);

    return () => {
      document.removeEventListener('click', handleDocumentClick);
    };
  }, [state.isAudioHelpEnabled]);

  return (
    <div className={cn(
      'min-h-screen transition-all duration-300',
      getEasyViewClasses(state.isEasyViewEnabled),
      state.isEasyViewEnabled
        ? 'bg-black text-yellow-400'
        : 'bg-gradient-to-br from-civic-blue-50 via-white to-civic-green-50'
    )}>
      {/* Top Navigation Bar */}
      <header className={cn(
        'sticky top-0 z-50 px-3 py-2 border-b transition-colors',
        state.isEasyViewEnabled
          ? 'bg-black border-yellow-400'
          : 'bg-white/95 backdrop-blur-xl border-civic-blue-200 shadow-lg shadow-civic-blue-100/50'
      )}>
        <div className="flex items-center justify-between w-full max-w-sm mx-auto sm:max-w-md md:max-w-2xl lg:max-w-4xl">
          {/* Logo/Title */}
          <div className="flex items-center gap-2">
            <Link to="/dashboard" className="flex items-center gap-1.5">
              <div className={cn(
                'w-7 h-7 rounded-lg flex items-center justify-center',
                state.isEasyViewEnabled ? 'bg-yellow-400 text-black' : 'bg-civic-blue-500 text-white'
              )}>
                <Home className="w-4 h-4" />
              </div>
              <h1 className={cn(
                'font-semibold transition-all truncate',
                state.isEasyViewEnabled ? 'text-lg sm:text-xl text-yellow-400' : 'text-sm sm:text-base text-gray-800'
              )}>
                {title.split(' - ')[0]}
              </h1>
            </Link>
          </div>

          {/* Audio Help Toggle */}
          <div className="relative flex items-center gap-1">
            <Button
              onClick={handleAudioHelpToggle}
              variant={state.isAudioHelpEnabled ? "default" : "outline"}
              size="sm"
              className={cn(
                'flex items-center gap-1 transition-all duration-300 text-xs sm:text-sm',
                state.isAudioHelpEnabled
                  ? (state.isEasyViewEnabled ? 'bg-yellow-400 text-black hover:bg-yellow-500' : 'bg-civic-green-600 text-white hover:bg-civic-green-700')
                  : (state.isEasyViewEnabled ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' : 'border-civic-blue-300 text-civic-blue-600 hover:bg-civic-blue-50')
              )}
              aria-label={`Audio Help is ${state.isAudioHelpEnabled ? 'ON' : 'OFF'}`}
            >
              {state.isAudioHelpEnabled ? (
                <Headphones className="w-4 h-4" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
              <span className="font-medium hidden xs:inline">
                Audio
              </span>
            </Button>

            {/* Tooltip */}
            {showTooltip && (
              <div className={cn(
                'absolute top-full mt-2 right-0 z-50 p-3 rounded-lg shadow-lg border max-w-xs',
                state.isEasyViewEnabled
                  ? 'bg-black border-yellow-400 text-yellow-400'
                  : 'bg-white border-civic-blue-200 text-gray-800'
              )}>
                <p className="text-sm">
                  {state.isAudioHelpEnabled
                    ? '🔊 Audio Help is ON. Tap any item to hear it spoken aloud.'
                    : '🔇 Audio Help is OFF. Long-press any item to hear it.'
                  }
                </p>
              </div>
            )}
          </div>

          {/* Other Controls */}
          <div className="flex items-center gap-1">
            {/* Easy View Toggle */}
            <Button
              variant={state.isEasyViewEnabled ? "default" : "outline"}
              size="sm"
              onClick={toggleEasyView}
              className={cn(
                'flex items-center gap-1 text-xs sm:text-sm',
                state.isEasyViewEnabled
                  ? 'bg-yellow-400 text-black hover:bg-yellow-500'
                  : 'border-civic-blue-500 text-civic-blue-600'
              )}
              aria-label="Toggle easy view mode"
            >
              <Eye className="w-4 h-4" />
              <span className="hidden xs:inline">Easy</span>
            </Button>

            {/* Settings Link */}
            <Link to="/settings">
              <Button
                variant="ghost"
                size="sm"
                className={cn(
                  'h-8 w-8 p-0',
                  state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-gray-600'
                )}
                aria-label="Open settings"
              >
                <Settings className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className={cn(
        'flex-1 transition-all duration-300 pb-20', // Added bottom padding to prevent overlap
        state.isEasyViewEnabled ? 'px-3 py-4' : 'px-3 py-3'
      )}>
        <div className="w-full max-w-sm mx-auto sm:max-w-md md:max-w-2xl lg:max-w-4xl">
          {children}
        </div>
      </main>

      {/* Bottom Controls - Fixed at bottom with better positioning */}
      <div className="fixed bottom-2 left-1/2 transform -translate-x-1/2 z-40 flex items-center gap-3">
        {/* Read This Screen Button */}
        <Button
          onClick={handleReadScreen}
          className={cn(
            'flex items-center gap-1.5 px-3 py-2 rounded-full shadow-lg transition-all duration-300 hover:scale-105',
            state.isEasyViewEnabled
              ? 'bg-yellow-400 text-black hover:bg-yellow-500 shadow-yellow-400/50'
              : 'bg-civic-green-600 text-white hover:bg-civic-green-700 shadow-civic-green-600/50'
          )}
          aria-label="Read screen summary aloud"
        >
          <Speaker className="w-4 h-4" />
          <span className="font-medium text-xs sm:text-sm">Read</span>
        </Button>

        {/* Voice Command Button */}
        <Button
          onClick={startVoiceCommand}
          className={cn(
            'rounded-full w-12 h-12 shadow-lg transition-all duration-300 hover:scale-110',
            state.isEasyViewEnabled
              ? 'bg-yellow-400 text-black hover:bg-yellow-500 shadow-yellow-400/50'
              : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700 shadow-civic-blue-600/50'
          )}
          aria-label="Activate voice commands"
        >
          <Mic className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
};
