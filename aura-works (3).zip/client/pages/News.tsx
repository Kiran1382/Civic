import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { readAloud } from '@/lib/accessibility';
import { 
  Newspaper,
  Volume2,
  Calendar,
  Clock,
  ExternalLink,
  Search,
  Filter,
  Play,
  Pause,
  SkipForward,
  Star,
  Share
} from 'lucide-react';

const newsCategories = [
  { id: 'all', name: 'All News', icon: '📰' },
  { id: 'announcements', name: 'Announcements', icon: '📢' },
  { id: 'schemes', name: 'Schemes & Benefits', icon: '💰' },
  { id: 'healthcare', name: 'Healthcare', icon: '🏥' },
  { id: 'infrastructure', name: 'Infrastructure', icon: '🚧' },
  { id: 'environment', name: 'Environment', icon: '🌱' }
];

const newsArticles = [
  {
    id: 1,
    title: 'New Healthcare Scheme for Senior Citizens Launched',
    category: 'healthcare',
    summary: 'Government announces comprehensive healthcare coverage for citizens above 65 years with free medicines and home visits.',
    content: 'The state government has officially launched a new healthcare scheme specifically designed for senior citizens. The scheme provides free medical checkups, basic medicines, and home healthcare services for citizens above 65 years of age. Registration is now open at all community health centers.',
    publishedAt: '2024-01-12T10:30:00Z',
    readTime: '3 min read',
    important: true,
    source: 'Ministry of Health',
    isBookmarked: false
  },
  {
    id: 2,
    title: 'Digital Voter ID Cards Now Available for Download',
    category: 'announcements',
    summary: 'Citizens can now download digital voter ID cards through the official portal with OTP verification.',
    content: 'The Election Commission has enabled digital voter ID card downloads through the official civic portal. Citizens can verify their identity using OTP and download a secure digital copy of their voter ID card. This digital card is legally valid for all voting purposes.',
    publishedAt: '2024-01-11T14:15:00Z',
    readTime: '2 min read',
    important: true,
    source: 'Election Commission',
    isBookmarked: true
  },
  {
    id: 3,
    title: 'Community Garden Initiative Receives Funding',
    category: 'environment',
    summary: 'Local community gardens project approved with ₹2 crore funding to convert vacant plots into green spaces.',
    content: 'The municipal corporation has approved funding for the community garden initiative. Five vacant plots across the city will be converted into community gardens where residents can grow vegetables and flowers. The project includes composting facilities and gardening workshops.',
    publishedAt: '2024-01-10T09:45:00Z',
    readTime: '4 min read',
    important: false,
    source: 'Municipal Corporation',
    isBookmarked: false
  },
  {
    id: 4,
    title: 'Street Light Modernization Project Begins',
    category: 'infrastructure',
    summary: 'LED street light installation starts this week across 500+ streets to improve safety and reduce energy costs.',
    content: 'The street light modernization project has commenced with the installation of energy-efficient LED lights. The project will cover over 500 streets in residential areas, providing better illumination while reducing electricity consumption by 60%.',
    publishedAt: '2024-01-09T16:20:00Z',
    readTime: '3 min read',
    important: false,
    source: 'Public Works Department',
    isBookmarked: false
  },
  {
    id: 5,
    title: 'Free Digital Literacy Classes for Seniors',
    category: 'schemes',
    summary: 'Weekly smartphone and internet training sessions available at public libraries starting next Monday.',
    content: 'Free digital literacy classes are now available for senior citizens at all public libraries. The program covers basic smartphone usage, online government services, digital payments, and internet safety. Classes are held twice a week with individual assistance.',
    publishedAt: '2024-01-08T11:10:00Z',
    readTime: '2 min read',
    important: false,
    source: 'Digital India Initiative',
    isBookmarked: false
  }
];

export default function News() {
  const { state } = useAccessibility();
  const [articles, setArticles] = useState(newsArticles);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentlyReading, setCurrentlyReading] = useState<number | null>(null);
  const [expandedArticle, setExpandedArticle] = useState<number | null>(null);

  const handleReadAloud = (text: string) => {
    readAloud(text);
  };

  const toggleBookmark = (articleId: number) => {
    const updatedArticles = articles.map(article => {
      if (article.id === articleId) {
        const newBookmarkStatus = !article.isBookmarked;
        readAloud(newBookmarkStatus ? 'Article bookmarked' : 'Bookmark removed');
        return { ...article, isBookmarked: newBookmarkStatus };
      }
      return article;
    });
    setArticles(updatedArticles);
  };

  const readArticle = (article: any) => {
    setCurrentlyReading(article.id);
    const fullText = `${article.title}. ${article.summary}. ${article.content}. Published by ${article.source}.`;
    readAloud(fullText);
    
    // Simulate reading time
    setTimeout(() => {
      setCurrentlyReading(null);
    }, 10000);
  };

  const stopReading = () => {
    setCurrentlyReading(null);
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    readAloud('Reading stopped');
  };

  const nextNews = () => {
    const currentIndex = filteredArticles.findIndex(article => article.id === currentlyReading);
    if (currentIndex < filteredArticles.length - 1) {
      const nextArticle = filteredArticles[currentIndex + 1];
      readArticle(nextArticle);
    } else {
      readAloud('This was the last news article');
      setCurrentlyReading(null);
    }
  };

  const filteredArticles = articles.filter(article => {
    const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         article.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         article.content.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const importantNews = filteredArticles.filter(article => article.important);
  const regularNews = filteredArticles.filter(article => !article.important);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    return `${diffDays} days ago`;
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={cn(
        'text-center space-y-4 p-6 rounded-xl',
        state.isEasyViewEnabled 
          ? 'bg-black text-yellow-400' 
          : 'bg-white border border-civic-blue-200'
      )}>
        <div className="flex items-center justify-center gap-3">
          <Newspaper className={cn(
            'w-10 h-10',
            state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
          )} />
          <h1 className={cn(
            'font-bold',
            state.isEasyViewEnabled ? 'text-3xl' : 'text-2xl text-gray-800'
          )}>
            Government News
          </h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleReadAloud('Government News. Stay updated with the latest government news and announcements with voice support.')}
            className={cn(
              'h-8 w-8 p-0',
              state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
            )}
          >
            <Volume2 className="w-4 h-4" />
          </Button>
        </div>
        <p className={cn(
          'max-w-2xl mx-auto leading-relaxed',
          state.isEasyViewEnabled ? 'text-xl text-yellow-300' : 'text-gray-600'
        )}>
          Stay updated with the latest government news and announcements
        </p>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className={cn(
              'absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5',
              state.isEasyViewEnabled ? 'text-yellow-600' : 'text-gray-400'
            )} />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search news articles..."
              className={cn(
                'pl-10',
                state.isEasyViewEnabled 
                  ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                  : 'border-civic-blue-300'
              )}
            />
          </div>
        </div>

        <div className="flex overflow-x-auto gap-2 pb-2">
          {newsCategories.map((category) => (
            <Button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              variant={selectedCategory === category.id ? "default" : "outline"}
              className={cn(
                'flex items-center gap-2 whitespace-nowrap',
                selectedCategory === category.id
                  ? (state.isEasyViewEnabled ? 'bg-yellow-400 text-black' : 'bg-civic-blue-600 text-white')
                  : (state.isEasyViewEnabled ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' : 'border-civic-blue-300 text-civic-blue-600')
              )}
            >
              <span>{category.icon}</span>
              <span>{category.name}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Voice Controls */}
      {currentlyReading && (
        <Card className={cn(
          'p-4 border-2',
          state.isEasyViewEnabled 
            ? 'bg-black border-yellow-400' 
            : 'bg-civic-blue-50 border-civic-blue-200'
        )}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={cn(
                'w-3 h-3 rounded-full animate-pulse',
                state.isEasyViewEnabled ? 'bg-yellow-400' : 'bg-civic-blue-600'
              )} />
              <span className={cn(
                'font-medium',
                state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-800'
              )}>
                Reading article...
              </span>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                onClick={nextNews}
                size="sm"
                className={cn(
                  'flex items-center gap-1',
                  state.isEasyViewEnabled 
                    ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                    : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
                )}
              >
                <SkipForward className="w-4 h-4" />
                Next News
              </Button>
              
              <Button
                onClick={stopReading}
                size="sm"
                variant="outline"
                className={cn(
                  'flex items-center gap-1',
                  state.isEasyViewEnabled 
                    ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                    : 'border-gray-300 text-gray-600'
                )}
              >
                <Pause className="w-4 h-4" />
                Stop
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Important News */}
      {importantNews.length > 0 && (
        <div className="space-y-4">
          <h2 className={cn(
            'font-semibold flex items-center gap-2',
            state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
          )}>
            <Star className="w-6 h-6" />
            Important Announcements
          </h2>
          
          <div className="grid grid-cols-1 gap-4">
            {importantNews.map((article) => (
              <Card 
                key={article.id}
                className={cn(
                  'p-6 border-2 transition-all duration-300',
                  state.isEasyViewEnabled 
                    ? 'bg-black border-yellow-400' 
                    : 'bg-red-50 border-red-200 hover:border-red-400'
                )}
              >
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2">
                        <span className={cn(
                          'px-2 py-1 rounded-full text-xs font-medium',
                          state.isEasyViewEnabled 
                            ? 'bg-red-400/20 text-red-400' 
                            : 'bg-red-100 text-red-700'
                        )}>
                          IMPORTANT
                        </span>
                        <span className={cn(
                          'text-sm',
                          state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                        )}>
                          {getTimeAgo(article.publishedAt)}
                        </span>
                      </div>
                      
                      <h3 className={cn(
                        'font-semibold leading-tight',
                        state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-gray-800'
                      )}>
                        {article.title}
                      </h3>
                      
                      <p className={cn(
                        'leading-relaxed',
                        state.isEasyViewEnabled ? 'text-lg text-yellow-300' : 'text-gray-600'
                      )}>
                        {article.summary}
                      </p>
                    </div>
                    
                    <Button
                      onClick={() => toggleBookmark(article.id)}
                      variant="ghost"
                      size="sm"
                      className={cn(
                        'ml-2',
                        article.isBookmarked 
                          ? (state.isEasyViewEnabled ? 'text-yellow-400' : 'text-blue-600')
                          : (state.isEasyViewEnabled ? 'text-yellow-600' : 'text-gray-400')
                      )}
                    >
                      <Star className={cn('w-5 h-5', article.isBookmarked && 'fill-current')} />
                    </Button>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <div className={cn(
                      'flex items-center gap-4',
                      state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                    )}>
                      <span>By {article.source}</span>
                      <span>{article.readTime}</span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={() => readArticle(article)}
                      disabled={currentlyReading === article.id}
                      className={cn(
                        'flex items-center gap-2',
                        state.isEasyViewEnabled 
                          ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                          : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
                      )}
                    >
                      <Play className="w-4 h-4" />
                      {currentlyReading === article.id ? 'Reading...' : 'Read Aloud'}
                    </Button>
                    
                    <Button
                      onClick={() => setExpandedArticle(expandedArticle === article.id ? null : article.id)}
                      variant="outline"
                      className={cn(
                        state.isEasyViewEnabled 
                          ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                          : 'border-civic-blue-300 text-civic-blue-600'
                      )}
                    >
                      {expandedArticle === article.id ? 'Hide Details' : 'Read Full Article'}
                    </Button>
                  </div>

                  {expandedArticle === article.id && (
                    <div className={cn(
                      'p-4 rounded-lg border',
                      state.isEasyViewEnabled 
                        ? 'border-yellow-400 bg-yellow-400/10' 
                        : 'border-civic-blue-200 bg-civic-blue-50'
                    )}>
                      <p className={cn(
                        'leading-relaxed',
                        state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
                      )}>
                        {article.content}
                      </p>
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Regular News */}
      <div className="space-y-4">
        <h2 className={cn(
          'font-semibold',
          state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
        )}>
          Latest News ({regularNews.length})
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {regularNews.map((article) => (
            <Card 
              key={article.id}
              className={cn(
                'p-6 transition-all duration-300 hover:scale-105 border-2',
                state.isEasyViewEnabled 
                  ? 'bg-black border-yellow-400' 
                  : 'bg-white border-civic-blue-200 hover:border-civic-blue-400 hover:shadow-lg'
              )}
            >
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className={cn(
                        'px-2 py-1 rounded-full text-xs font-medium',
                        state.isEasyViewEnabled 
                          ? 'bg-yellow-400/20 text-yellow-400' 
                          : 'bg-civic-blue-100 text-civic-blue-700'
                      )}>
                        {newsCategories.find(cat => cat.id === article.category)?.name}
                      </span>
                      <span className={cn(
                        'text-sm',
                        state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                      )}>
                        {getTimeAgo(article.publishedAt)}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <h3 className={cn(
                        'font-semibold leading-tight',
                        state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-gray-800'
                      )}>
                        {article.title}
                      </h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleReadAloud(`${article.title}. ${article.summary}`)}
                        className={cn(
                          'h-6 w-6 p-0',
                          state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-500'
                        )}
                      >
                        <Volume2 className="w-3 h-3" />
                      </Button>
                    </div>
                    
                    <p className={cn(
                      'leading-relaxed',
                      state.isEasyViewEnabled ? 'text-lg text-yellow-300' : 'text-gray-600'
                    )}>
                      {article.summary}
                    </p>
                  </div>
                  
                  <Button
                    onClick={() => toggleBookmark(article.id)}
                    variant="ghost"
                    size="sm"
                    className={cn(
                      'ml-2',
                      article.isBookmarked 
                        ? (state.isEasyViewEnabled ? 'text-yellow-400' : 'text-blue-600')
                        : (state.isEasyViewEnabled ? 'text-yellow-600' : 'text-gray-400')
                    )}
                  >
                    <Star className={cn('w-5 h-5', article.isBookmarked && 'fill-current')} />
                  </Button>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <div className={cn(
                    'flex items-center gap-4',
                    state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                  )}>
                    <span>By {article.source}</span>
                    <span>{article.readTime}</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => readArticle(article)}
                    disabled={currentlyReading === article.id}
                    className={cn(
                      'flex-1 flex items-center gap-2',
                      state.isEasyViewEnabled 
                        ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                        : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
                    )}
                  >
                    <Play className="w-4 h-4" />
                    {currentlyReading === article.id ? 'Reading...' : 'Read Aloud'}
                  </Button>
                  
                  <Button
                    onClick={() => setExpandedArticle(expandedArticle === article.id ? null : article.id)}
                    variant="outline"
                    className={cn(
                      'flex-1',
                      state.isEasyViewEnabled 
                        ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                        : 'border-civic-blue-300 text-civic-blue-600'
                    )}
                  >
                    {expandedArticle === article.id ? 'Hide' : 'Full Article'}
                  </Button>
                </div>

                {expandedArticle === article.id && (
                  <div className={cn(
                    'p-4 rounded-lg border',
                    state.isEasyViewEnabled 
                      ? 'border-yellow-400 bg-yellow-400/10' 
                      : 'border-civic-blue-200 bg-civic-blue-50'
                  )}>
                    <p className={cn(
                      'leading-relaxed',
                      state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
                    )}>
                      {article.content}
                    </p>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Voice Commands Help */}
      <Card className={cn(
        'p-6 border-2',
        state.isEasyViewEnabled 
          ? 'bg-black border-yellow-400' 
          : 'bg-civic-blue-50 border-civic-blue-200'
      )}>
        <div className="space-y-4">
          <h3 className={cn(
            'font-semibold',
            state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-civic-blue-800'
          )}>
            Voice Commands for News
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              '"Next News" - Skip to next article',
              '"Stop Reading" - Stop current article',
              '"Read Headlines" - Read all headlines',
              '"Important News" - Read important news only'
            ].map((command, index) => (
              <div 
                key={index}
                className={cn(
                  'p-3 rounded-lg border',
                  state.isEasyViewEnabled 
                    ? 'border-yellow-400 bg-yellow-400/10' 
                    : 'border-civic-blue-200 bg-white'
                )}
              >
                <span className={cn(
                  'font-mono text-sm',
                  state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
                )}>
                  {command}
                </span>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}
