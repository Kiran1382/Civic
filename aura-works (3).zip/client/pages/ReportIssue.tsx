import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { readAloud } from '@/lib/accessibility';
import { 
  AlertTriangle,
  Camera,
  MapPin,
  Mic,
  Volume2,
  CheckCircle,
  Upload,
  Navigation,
  Phone,
  FileImage,
  X,
  Send
} from 'lucide-react';

const issueCategories = [
  { id: 'roads', name: 'Roads & Transport', icon: '🛣️', description: 'Potholes, broken roads, traffic issues' },
  { id: 'water', name: 'Water Supply', icon: '💧', description: 'Water shortage, leakage, quality issues' },
  { id: 'electricity', name: 'Electricity', icon: '⚡', description: 'Power cuts, street light issues' },
  { id: 'waste', name: 'Waste Management', icon: '🗑️', description: 'Garbage collection, cleanliness' },
  { id: 'safety', name: 'Public Safety', icon: '🚨', description: 'Safety concerns, emergencies' },
  { id: 'other', name: 'Other Issues', icon: '📝', description: 'Any other community problem' }
];

export default function ReportIssue() {
  const { state } = useAccessibility();
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [uploadedPhotos, setUploadedPhotos] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleReadAloud = (text: string) => {
    readAloud(text);
  };

  const handleCategorySelect = (categoryId: string, category: any) => {
    setSelectedCategory(categoryId);
    readAloud(`Selected category: ${category.name}. ${category.description}`);
  };

  const handleVoiceInput = () => {
    setIsRecording(true);
    readAloud('Voice recording started. Describe your issue clearly.');
    
    // Simulate voice recording
    setTimeout(() => {
      setIsRecording(false);
      const mockTranscription = "There is a large pothole on Main Street near the community center. It's causing problems for vehicles and pedestrians. The issue has been there for over a week.";
      setDescription(mockTranscription);
      readAloud('Voice recording completed. Your description has been added to the form.');
    }, 3000);
  };

  const handlePhotoUpload = () => {
    // Simulate photo upload
    const mockPhotoUrl = `https://via.placeholder.com/300x200/4ade80/ffffff?text=Issue+Photo+${uploadedPhotos.length + 1}`;
    setUploadedPhotos([...uploadedPhotos, mockPhotoUrl]);
    readAloud(`Photo ${uploadedPhotos.length + 1} uploaded successfully.`);
  };

  const removePhoto = (index: number) => {
    const newPhotos = uploadedPhotos.filter((_, i) => i !== index);
    setUploadedPhotos(newPhotos);
    readAloud(`Photo ${index + 1} removed.`);
  };

  const getCurrentLocation = () => {
    readAloud('Getting your current location...');
    // Simulate getting location
    setTimeout(() => {
      setLocation('Main Street, Sector 15, Near Community Center');
      readAloud('Location detected and added to your report.');
    }, 2000);
  };

  const handleSubmit = () => {
    if (!selectedCategory || !title || !description) {
      readAloud('Please fill in all required fields: category, title, and description.');
      return;
    }

    setIsSubmitting(true);
    readAloud('Submitting your report...');

    // Simulate submission
    setTimeout(() => {
      setIsSubmitting(false);
      setShowSuccess(true);
      readAloud('Your report has been submitted successfully! Report ID: IR-2024-001. You will receive updates on your phone.');
    }, 3000);
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className={cn(
          'w-full max-w-md p-8 text-center space-y-6 border-2',
          state.isEasyViewEnabled 
            ? 'bg-black border-yellow-400' 
            : 'bg-white border-civic-green-200 shadow-xl'
        )}>
          <CheckCircle className={cn(
            'w-16 h-16 mx-auto',
            state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-green-600'
          )} />
          
          <div className="space-y-4">
            <h1 className={cn(
              'font-bold',
              state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
            )}>
              Report Submitted!
            </h1>
            
            <div className="space-y-2">
              <p className={cn(
                state.isEasyViewEnabled ? 'text-lg text-yellow-300' : 'text-gray-600'
              )}>
                Your report has been submitted successfully.
              </p>
              <div className={cn(
                'p-3 rounded-lg',
                state.isEasyViewEnabled ? 'bg-yellow-400/20' : 'bg-civic-green-100'
              )}>
                <p className={cn(
                  'font-mono font-semibold',
                  state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-green-800'
                )}>
                  Report ID: IR-2024-001
                </p>
              </div>
              <p className={cn(
                'text-sm',
                state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
              )}>
                You will receive updates on your registered mobile number.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <Button
              onClick={() => setShowSuccess(false)}
              className={cn(
                'w-full',
                state.isEasyViewEnabled 
                  ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                  : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
              )}
            >
              Report Another Issue
            </Button>
            
            <Button
              onClick={() => window.history.back()}
              variant="outline"
              className={cn(
                'w-full',
                state.isEasyViewEnabled 
                  ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                  : 'border-gray-300 text-gray-600'
              )}
            >
              Back to Dashboard
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={cn(
        'text-center space-y-4 p-6 rounded-xl',
        state.isEasyViewEnabled 
          ? 'bg-black text-yellow-400' 
          : 'bg-white border border-civic-blue-200'
      )}>
        <div className="flex items-center justify-center gap-3">
          <AlertTriangle className={cn(
            'w-10 h-10',
            state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
          )} />
          <h1 className={cn(
            'font-bold',
            state.isEasyViewEnabled ? 'text-3xl' : 'text-2xl text-gray-800'
          )}>
            Report Local Issue
          </h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleReadAloud('Report Local Issue. Help improve your community by reporting problems with photos and voice descriptions.')}
            className={cn(
              'h-8 w-8 p-0',
              state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
            )}
          >
            <Volume2 className="w-4 h-4" />
          </Button>
        </div>
        <p className={cn(
          'max-w-2xl mx-auto leading-relaxed',
          state.isEasyViewEnabled ? 'text-xl text-yellow-300' : 'text-gray-600'
        )}>
          Help improve your community by reporting problems with photos and voice descriptions
        </p>
      </div>

      {/* Category Selection */}
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <h2 className={cn(
            'font-semibold',
            state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
          )}>
            Select Issue Category
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleReadAloud('Select Issue Category. Choose the type of problem you want to report.')}
            className={cn(
              'h-8 w-8 p-0',
              state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
            )}
          >
            <Volume2 className="w-4 h-4" />
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {issueCategories.map((category) => (
            <Card 
              key={category.id}
              className={cn(
                'p-4 cursor-pointer transition-all duration-300 border-2 hover:scale-105',
                selectedCategory === category.id 
                  ? (state.isEasyViewEnabled ? 'border-yellow-400 bg-yellow-400/20' : 'border-civic-blue-500 bg-civic-blue-50')
                  : (state.isEasyViewEnabled ? 'border-yellow-600 bg-black' : 'border-civic-blue-200 bg-white')
              )}
              onClick={() => handleCategorySelect(category.id, category)}
            >
              <div className="text-center space-y-2">
                <div className="text-3xl">{category.icon}</div>
                <h3 className={cn(
                  'font-medium',
                  state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-800'
                )}>
                  {category.name}
                </h3>
                <p className={cn(
                  'text-sm',
                  state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                )}>
                  {category.description}
                </p>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Issue Details Form */}
      {selectedCategory && (
        <Card className={cn(
          'p-6 border-2',
          state.isEasyViewEnabled 
            ? 'bg-black border-yellow-400' 
            : 'bg-white border-civic-blue-200'
        )}>
          <div className="space-y-6">
            <h3 className={cn(
              'font-semibold flex items-center gap-2',
              state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-gray-800'
            )}>
              Issue Details
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleReadAloud('Issue Details. Fill in the information about the problem you want to report.')}
                className={cn(
                  'h-6 w-6 p-0',
                  state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-500'
                )}
              >
                <Volume2 className="w-3 h-3" />
              </Button>
            </h3>

            {/* Title */}
            <div className="space-y-2">
              <Label className={cn(
                'font-medium flex items-center gap-2',
                state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
              )}>
                Issue Title *
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleReadAloud('Issue Title. Enter a brief description of the problem.')}
                  className={cn(
                    'h-5 w-5 p-0',
                    state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-500'
                  )}
                >
                  <Volume2 className="w-3 h-3" />
                </Button>
              </Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Brief description of the issue"
                className={cn(
                  state.isEasyViewEnabled 
                    ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                    : 'border-civic-blue-300'
                )}
              />
            </div>

            {/* Description with Voice Input */}
            <div className="space-y-2">
              <Label className={cn(
                'font-medium flex items-center gap-2',
                state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
              )}>
                Detailed Description *
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleReadAloud('Detailed Description. Describe the issue in detail or use voice input.')}
                  className={cn(
                    'h-5 w-5 p-0',
                    state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-500'
                  )}
                >
                  <Volume2 className="w-3 h-3" />
                </Button>
              </Label>
              
              <div className="flex gap-2">
                <Textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe the issue in detail..."
                  rows={4}
                  className={cn(
                    'flex-1',
                    state.isEasyViewEnabled 
                      ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                      : 'border-civic-blue-300'
                  )}
                />
                <Button
                  onClick={handleVoiceInput}
                  disabled={isRecording}
                  className={cn(
                    'h-fit flex flex-col gap-1 px-3 py-2',
                    isRecording 
                      ? (state.isEasyViewEnabled ? 'bg-red-600 text-white' : 'bg-red-500 text-white')
                      : (state.isEasyViewEnabled ? 'bg-yellow-400 text-black hover:bg-yellow-500' : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700')
                  )}
                >
                  <Mic className="w-5 h-5" />
                  <span className="text-xs">{isRecording ? 'Recording...' : 'Voice'}</span>
                </Button>
              </div>
            </div>

            {/* Location */}
            <div className="space-y-2">
              <Label className={cn(
                'font-medium flex items-center gap-2',
                state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
              )}>
                Location
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleReadAloud('Location. Enter the location where the issue is located.')}
                  className={cn(
                    'h-5 w-5 p-0',
                    state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-500'
                  )}
                >
                  <Volume2 className="w-3 h-3" />
                </Button>
              </Label>
              
              <div className="flex gap-2">
                <Input
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Enter location or address"
                  className={cn(
                    'flex-1',
                    state.isEasyViewEnabled 
                      ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                      : 'border-civic-blue-300'
                  )}
                />
                <Button
                  onClick={getCurrentLocation}
                  variant="outline"
                  className={cn(
                    'flex items-center gap-2',
                    state.isEasyViewEnabled 
                      ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                      : 'border-civic-blue-300 text-civic-blue-600'
                  )}
                >
                  <Navigation className="w-4 h-4" />
                  Auto-detect
                </Button>
              </div>
            </div>

            {/* Photo Upload */}
            <div className="space-y-4">
              <Label className={cn(
                'font-medium flex items-center gap-2',
                state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
              )}>
                Add Photos (Optional)
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleReadAloud('Add Photos. Upload photos to help authorities understand the issue better.')}
                  className={cn(
                    'h-5 w-5 p-0',
                    state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-500'
                  )}
                >
                  <Volume2 className="w-3 h-3" />
                </Button>
              </Label>

              <Button
                onClick={handlePhotoUpload}
                variant="outline"
                className={cn(
                  'w-full h-20 flex flex-col gap-2 border-2 border-dashed',
                  state.isEasyViewEnabled 
                    ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                    : 'border-civic-blue-300 text-civic-blue-600 hover:bg-civic-blue-50'
                )}
              >
                <Camera className="w-8 h-8" />
                <span>Take Photo / Upload Image</span>
              </Button>

              {uploadedPhotos.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {uploadedPhotos.map((photo, index) => (
                    <div key={index} className="relative">
                      <img 
                        src={photo} 
                        alt={`Issue photo ${index + 1}`}
                        className="w-full h-24 object-cover rounded-lg border-2 border-civic-blue-200"
                      />
                      <Button
                        onClick={() => removePhoto(index)}
                        size="sm"
                        variant="destructive"
                        className="absolute -top-2 -right-2 h-6 w-6 p-0 rounded-full"
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Submit Button */}
            <Button
              onClick={handleSubmit}
              disabled={isSubmitting || !selectedCategory || !title || !description}
              className={cn(
                'w-full h-14 text-lg font-semibold transition-all duration-300',
                state.isEasyViewEnabled 
                  ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                  : 'bg-civic-green-600 text-white hover:bg-civic-green-700',
                'disabled:opacity-50'
              )}
            >
              {isSubmitting ? (
                <div className="flex items-center gap-2">
                  <Upload className="w-5 h-5 animate-spin" />
                  Submitting Report...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Send className="w-5 h-5" />
                  Submit Report
                </div>
              )}
            </Button>
          </div>
        </Card>
      )}

      {/* Emergency Contact */}
      <Card className={cn(
        'p-6 border-2',
        state.isEasyViewEnabled 
          ? 'bg-black border-yellow-400' 
          : 'bg-red-50 border-red-200'
      )}>
        <div className="flex items-start gap-3">
          <Phone className={cn(
            'w-6 h-6 mt-1',
            state.isEasyViewEnabled ? 'text-yellow-400' : 'text-red-600'
          )} />
          <div className="space-y-2">
            <h3 className={cn(
              'font-semibold',
              state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-red-800'
            )}>
              Emergency Issues?
            </h3>
            <p className={cn(
              state.isEasyViewEnabled ? 'text-yellow-300' : 'text-red-700'
            )}>
              For urgent safety issues or emergencies, call directly:
            </p>
            <div className="flex flex-col sm:flex-row gap-2">
              <Button 
                className={cn(
                  'flex items-center gap-2',
                  state.isEasyViewEnabled 
                    ? 'bg-red-600 text-white hover:bg-red-700' 
                    : 'bg-red-600 text-white hover:bg-red-700'
                )}
              >
                <Phone className="w-4 h-4" />
                Emergency: 108
              </Button>
              <Button 
                variant="outline"
                className={cn(
                  'flex items-center gap-2',
                  state.isEasyViewEnabled 
                    ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                    : 'border-red-300 text-red-600'
                )}
              >
                <Phone className="w-4 h-4" />
                Municipal Office: 1800-XXX-XXXX
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
