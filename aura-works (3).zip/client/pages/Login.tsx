import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { readAloud, handleTouchToRead } from '@/lib/accessibility';
import { 
  Phone,
  Shield,
  Volume2,
  HelpCircle,
  CheckCircle,
  Mic
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const { state } = useAccessibility();
  const navigate = useNavigate();
  const [step, setStep] = useState<'mobile' | 'otp'>('mobile');
  const [mobileNumber, setMobileNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleReadAloud = (text: string) => {
    readAloud(text);
  };

  const handleSendOTP = async () => {
    if (mobileNumber.length < 10) {
      // Only announce validation errors if Audio Help is enabled
      if (state.isAudioHelpEnabled) {
        readAloud('Please enter a valid 10-digit mobile number');
      }
      return;
    }

    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      setStep('otp');
      // Only announce if Audio Help is enabled
      if (state.isAudioHelpEnabled) {
        readAloud('OTP has been sent to your mobile number. Please enter the 6-digit code.');
      }
    }, 2000);
  };

  const handleVerifyOTP = async () => {
    if (otp.length < 6) {
      // Only announce validation errors if Audio Help is enabled
      if (state.isAudioHelpEnabled) {
        readAloud('Please enter the complete 6-digit OTP');
      }
      return;
    }

    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      // Only announce success if Audio Help is enabled
      if (state.isAudioHelpEnabled) {
        readAloud('Login successful! Welcome to Civic Connect.');
      }
      navigate('/dashboard');
    }, 1500);
  };

  const handleVoiceInput = (field: 'mobile' | 'otp') => {
    const message = field === 'mobile'
      ? 'Voice input for mobile number - speak your 10-digit mobile number clearly'
      : 'Voice input for OTP - speak the 6-digit code you received';

    // Voice input is always allowed since user explicitly clicked the mic button
    readAloud(message, true);
    // This would integrate with Speech Recognition API in a real implementation
    alert(`${message}\n\nThis is a demo - voice input would be implemented here.`);
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-3 py-6">
      <Card className={cn(
        'w-full max-w-sm sm:max-w-md p-4 sm:p-6 space-y-4 sm:space-y-6 border-2 transition-all duration-300',
        state.isEasyViewEnabled
          ? 'bg-black border-yellow-400'
          : 'bg-white border-civic-blue-200 shadow-xl'
      )}>
        {/* Header */}
        <div className="text-center space-y-3 sm:space-y-4">
          <div className={cn(
            'w-12 h-12 sm:w-16 sm:h-16 mx-auto rounded-full flex items-center justify-center',
            state.isEasyViewEnabled
              ? 'bg-yellow-400 text-black'
              : 'bg-civic-blue-100 text-civic-blue-600'
          )}>
            {step === 'mobile' ? <Phone className="w-6 h-6 sm:w-8 sm:h-8" /> : <Shield className="w-6 h-6 sm:w-8 sm:h-8" />}
          </div>

          <h1 className={cn(
            'font-bold',
            state.isEasyViewEnabled ? 'text-xl sm:text-2xl text-yellow-400' : 'text-lg sm:text-xl text-gray-800'
          )}>
            {step === 'mobile' ? 'Welcome Back' : 'Verify OTP'}
          </h1>

          <p className={cn(
            'leading-relaxed text-sm sm:text-base',
            state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
          )}>
            {step === 'mobile'
              ? 'Enter your mobile number to receive a secure login code'
              : `Enter the 6-digit code sent to ${mobileNumber.replace(/(\d{3})(\d{3})(\d{4})/, '$1-***-$3')}`
            }
          </p>
        </div>

        {/* Mobile Number Step */}
        {step === 'mobile' && (
          <div className="space-y-6">
            <div className="space-y-3">
              <Label
                htmlFor="mobile"
                className={cn(
                  'font-medium',
                  state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                )}
              >
                Mobile Number
              </Label>
              
              <div className="flex gap-2">
                <Input
                  id="mobile"
                  type="tel"
                  placeholder="Enter 10-digit mobile number"
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, '').slice(0, 10))}
                  className={cn(
                    'flex-1 transition-all duration-300',
                    state.isEasyViewEnabled 
                      ? 'text-lg bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600' 
                      : 'border-civic-blue-300 focus:border-civic-blue-500'
                  )}
                  aria-label="Enter your 10-digit mobile number"
                  maxLength={10}
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handleVoiceInput('mobile')}
                  className={cn(
                    'flex-shrink-0',
                    state.isEasyViewEnabled 
                      ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                      : 'border-civic-blue-300 text-civic-blue-600'
                  )}
                  aria-label="Use voice input for mobile number"
                >
                  <Mic className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <Button
              onClick={handleSendOTP}
              disabled={isLoading || mobileNumber.length < 10}
              className={cn(
                'w-full transition-all duration-300',
                state.isEasyViewEnabled
                  ? 'bg-yellow-400 text-black hover:bg-yellow-500 text-base sm:text-lg py-4 sm:py-6'
                  : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700 py-3 sm:py-4'
              )}
              aria-label="Send OTP to your mobile number"
            >
              {isLoading ? 'Sending...' : 'Send OTP'}
            </Button>
          </div>
        )}

        {/* OTP Step */}
        {step === 'otp' && (
          <div className="space-y-6">
            <div className="space-y-3">
              <Label
                htmlFor="otp"
                className={cn(
                  'font-medium',
                  state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                )}
              >
                Enter OTP
              </Label>
              
              <div className="flex gap-2">
                <Input
                  id="otp"
                  type="text"
                  placeholder="Enter 6-digit OTP"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  className={cn(
                    'flex-1 text-center tracking-wider transition-all duration-300',
                    state.isEasyViewEnabled 
                      ? 'text-lg bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600' 
                      : 'border-civic-blue-300 focus:border-civic-blue-500'
                  )}
                  aria-label="Enter the 6-digit OTP sent to your mobile"
                  maxLength={6}
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handleVoiceInput('otp')}
                  className={cn(
                    'flex-shrink-0',
                    state.isEasyViewEnabled 
                      ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                      : 'border-civic-blue-300 text-civic-blue-600'
                  )}
                  aria-label="Use voice input for OTP"
                >
                  <Mic className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="space-y-3">
              <Button
                onClick={handleVerifyOTP}
                disabled={isLoading || otp.length < 6}
                className={cn(
                  'w-full transition-all duration-300',
                  state.isEasyViewEnabled
                    ? 'bg-yellow-400 text-black hover:bg-yellow-500 text-base sm:text-lg py-4 sm:py-6'
                    : 'bg-civic-green-600 text-white hover:bg-civic-green-700 py-3 sm:py-4'
                )}
                aria-label="Verify OTP and login"
              >
                {isLoading ? 'Verifying...' : (
                  <span className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5" />
                    Verify & Login
                  </span>
                )}
              </Button>

              <Button
                variant="outline"
                onClick={() => setStep('mobile')}
                className={cn(
                  'w-full',
                  state.isEasyViewEnabled 
                    ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                    : 'border-gray-300 text-gray-600'
                )}
                aria-label="Go back to mobile number step"
              >
                Change Mobile Number
              </Button>
            </div>
          </div>
        )}

        {/* Need Help Section */}
        <Card className={cn(
          'p-4 border text-center',
          state.isEasyViewEnabled 
            ? 'bg-black border-yellow-400' 
            : 'bg-civic-blue-50 border-civic-blue-200'
        )}>
          <div className="flex items-center justify-center gap-3 mb-2">
            <HelpCircle className={cn(
              'w-5 h-5',
              state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
            )} />
            <h3 className={cn(
              'font-medium',
              state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-civic-blue-800'
            )}>
              Need Help?
            </h3>
          </div>
          <p className={cn(
            'text-sm mb-3',
            state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
          )}>
            Call our support team for assistance with login or technical issues
          </p>
          <Button
            variant="outline"
            className={cn(
              'w-full',
              state.isEasyViewEnabled 
                ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                : 'border-civic-blue-300 text-civic-blue-600'
            )}
            onClick={() => readAloud('Calling support. Phone number: 1-800-CIVIC-HELP')}
            aria-label="Call support for help"
          >
            Call Support: 1-800-CIVIC-HELP
          </Button>
        </Card>
      </Card>
    </div>
  );
}
