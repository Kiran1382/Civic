import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { readAloud } from '@/lib/accessibility';
import { 
  UserPlus,
  Volume2,
  Upload,
  Camera,
  Mic,
  CheckCircle,
  Calendar,
  MapPin,
  Phone,
  FileText,
  AlertCircle,
  Send
} from 'lucide-react';

interface FormData {
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  gender: string;
  phoneNumber: string;
  email: string;
  address: string;
  pincode: string;
  aadhaarNumber: string;
  constituency: string;
}

const initialFormData: FormData = {
  firstName: '',
  lastName: '',
  dateOfBirth: '',
  gender: '',
  phoneNumber: '',
  email: '',
  address: '',
  pincode: '',
  aadhaarNumber: '',
  constituency: ''
};

const requiredDocuments = [
  { name: 'Aadhaar Card', uploaded: false, required: true },
  { name: 'Address Proof', uploaded: false, required: true },
  { name: 'Age Proof', uploaded: false, required: true },
  { name: 'Passport Photo', uploaded: false, required: true }
];

export default function VoterRegistration() {
  const { state } = useAccessibility();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [documents, setDocuments] = useState(requiredDocuments);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [errors, setErrors] = useState<Partial<FormData>>({});

  const handleReadAloud = (text: string) => {
    readAloud(text);
  };

  const handleVoiceInput = (field: keyof FormData) => {
    readAloud(`Voice input for ${field.replace(/([A-Z])/g, ' $1').toLowerCase()}. Speak clearly.`);
    // Simulate voice input
    setTimeout(() => {
      const mockInputs: Record<string, string> = {
        firstName: 'Rajesh',
        lastName: 'Kumar',
        address: '123 Main Street, Sector 15, Near Community Center',
        constituency: 'Central Delhi'
      };
      
      if (mockInputs[field]) {
        setFormData(prev => ({ ...prev, [field]: mockInputs[field] }));
        readAloud(`Voice input recorded for ${field.replace(/([A-Z])/g, ' $1').toLowerCase()}: ${mockInputs[field]}`);
      }
    }, 2000);
  };

  const handleDocumentUpload = (docIndex: number) => {
    const updatedDocs = documents.map((doc, index) => {
      if (index === docIndex) {
        readAloud(`${doc.name} uploaded successfully`);
        return { ...doc, uploaded: true };
      }
      return doc;
    });
    setDocuments(updatedDocs);
  };

  const validateStep = (step: number): boolean => {
    const newErrors: Partial<FormData> = {};
    
    if (step === 1) {
      if (!formData.firstName) newErrors.firstName = 'First name is required';
      if (!formData.lastName) newErrors.lastName = 'Last name is required';
      if (!formData.dateOfBirth) newErrors.dateOfBirth = 'Date of birth is required';
      if (!formData.gender) newErrors.gender = 'Gender is required';
      if (!formData.phoneNumber) newErrors.phoneNumber = 'Phone number is required';
    } else if (step === 2) {
      if (!formData.address) newErrors.address = 'Address is required';
      if (!formData.pincode) newErrors.pincode = 'Pincode is required';
      if (!formData.aadhaarNumber) newErrors.aadhaarNumber = 'Aadhaar number is required';
    }
    
    setErrors(newErrors);
    
    if (Object.keys(newErrors).length > 0) {
      const errorFields = Object.keys(newErrors).join(', ');
      readAloud(`Please fill in the required fields: ${errorFields}`);
      return false;
    }
    
    return true;
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => prev + 1);
      readAloud(`Moving to step ${currentStep + 1}`);
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => prev - 1);
    readAloud(`Going back to step ${currentStep - 1}`);
  };

  const handleSubmit = () => {
    const requiredDocsUploaded = documents.filter(doc => doc.required).every(doc => doc.uploaded);
    
    if (!requiredDocsUploaded) {
      readAloud('Please upload all required documents before submitting');
      return;
    }

    setIsSubmitting(true);
    readAloud('Submitting your voter registration application...');

    setTimeout(() => {
      setIsSubmitting(false);
      setShowSuccess(true);
      readAloud('Your voter registration application has been submitted successfully! Application ID: VR-2024-001. You will receive updates on your registered mobile number.');
    }, 3000);
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className={cn(
          'w-full max-w-md p-8 text-center space-y-6 border-2',
          state.isEasyViewEnabled 
            ? 'bg-black border-yellow-400' 
            : 'bg-white border-civic-green-200 shadow-xl'
        )}>
          <CheckCircle className={cn(
            'w-16 h-16 mx-auto',
            state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-green-600'
          )} />
          
          <div className="space-y-4">
            <h1 className={cn(
              'font-bold',
              state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
            )}>
              Registration Submitted!
            </h1>
            
            <div className="space-y-2">
              <p className={cn(
                state.isEasyViewEnabled ? 'text-lg text-yellow-300' : 'text-gray-600'
              )}>
                Your voter registration application has been submitted successfully.
              </p>
              <div className={cn(
                'p-3 rounded-lg',
                state.isEasyViewEnabled ? 'bg-yellow-400/20' : 'bg-civic-green-100'
              )}>
                <p className={cn(
                  'font-mono font-semibold',
                  state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-green-800'
                )}>
                  Application ID: VR-2024-001
                </p>
              </div>
              <p className={cn(
                'text-sm',
                state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
              )}>
                Processing time: 15-30 days. You will receive updates on your registered mobile number.
              </p>
            </div>
          </div>

          <Button
            onClick={() => window.history.back()}
            className={cn(
              'w-full',
              state.isEasyViewEnabled 
                ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
            )}
          >
            Back to Dashboard
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={cn(
        'text-center space-y-4 p-6 rounded-xl',
        state.isEasyViewEnabled 
          ? 'bg-black text-yellow-400' 
          : 'bg-white border border-civic-blue-200'
      )}>
        <div className="flex items-center justify-center gap-3">
          <UserPlus className={cn(
            'w-10 h-10',
            state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
          )} />
          <h1 className={cn(
            'font-bold',
            state.isEasyViewEnabled ? 'text-3xl' : 'text-2xl text-gray-800'
          )}>
            New Voter Registration
          </h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleReadAloud('New Voter Registration. Register as a new voter with step-by-step guidance and voice input assistance.')}
            className={cn(
              'h-8 w-8 p-0',
              state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
            )}
          >
            <Volume2 className="w-4 h-4" />
          </Button>
        </div>
        <p className={cn(
          'max-w-2xl mx-auto leading-relaxed',
          state.isEasyViewEnabled ? 'text-xl text-yellow-300' : 'text-gray-600'
        )}>
          Register as a new voter with step-by-step guidance and voice input assistance
        </p>
      </div>

      {/* Progress Indicator */}
      <div className="flex justify-center space-x-4">
        {[1, 2, 3].map((step) => (
          <div key={step} className="flex items-center">
            <div className={cn(
              'w-10 h-10 rounded-full flex items-center justify-center font-bold',
              step <= currentStep 
                ? (state.isEasyViewEnabled ? 'bg-yellow-400 text-black' : 'bg-civic-blue-500 text-white')
                : (state.isEasyViewEnabled ? 'bg-yellow-800 text-yellow-400' : 'bg-gray-300 text-gray-600')
            )}>
              {step}
            </div>
            {step < 3 && (
              <div className={cn(
                'w-16 h-1 mx-2',
                step < currentStep 
                  ? (state.isEasyViewEnabled ? 'bg-yellow-400' : 'bg-civic-blue-500')
                  : (state.isEasyViewEnabled ? 'bg-yellow-800' : 'bg-gray-300')
              )} />
            )}
          </div>
        ))}
      </div>

      {/* Step Content */}
      <Card className={cn(
        'p-6 border-2',
        state.isEasyViewEnabled 
          ? 'bg-black border-yellow-400' 
          : 'bg-white border-civic-blue-200'
      )}>
        {/* Step 1: Personal Information */}
        {currentStep === 1 && (
          <div className="space-y-6">
            <h2 className={cn(
              'font-semibold text-center',
              state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
            )}>
              Step 1: Personal Information
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label className={cn(
                  'font-medium flex items-center gap-2',
                  state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                )}>
                  First Name *
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleReadAloud('First Name field')}
                    className={cn(
                      'h-5 w-5 p-0',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-500'
                    )}
                  >
                    <Volume2 className="w-3 h-3" />
                  </Button>
                </Label>
                <div className="flex gap-2">
                  <Input
                    value={formData.firstName}
                    onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
                    placeholder="Enter your first name"
                    className={cn(
                      'flex-1',
                      errors.firstName && 'border-red-500',
                      state.isEasyViewEnabled 
                        ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                        : 'border-civic-blue-300'
                    )}
                  />
                  <Button
                    onClick={() => handleVoiceInput('firstName')}
                    variant="outline"
                    size="icon"
                    className={cn(
                      state.isEasyViewEnabled 
                        ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                        : 'border-civic-blue-300 text-civic-blue-600'
                    )}
                  >
                    <Mic className="w-4 h-4" />
                  </Button>
                </div>
                {errors.firstName && (
                  <p className="text-red-500 text-sm">{errors.firstName}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label className={cn(
                  'font-medium flex items-center gap-2',
                  state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                )}>
                  Last Name *
                </Label>
                <div className="flex gap-2">
                  <Input
                    value={formData.lastName}
                    onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
                    placeholder="Enter your last name"
                    className={cn(
                      'flex-1',
                      errors.lastName && 'border-red-500',
                      state.isEasyViewEnabled 
                        ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                        : 'border-civic-blue-300'
                    )}
                  />
                  <Button
                    onClick={() => handleVoiceInput('lastName')}
                    variant="outline"
                    size="icon"
                    className={cn(
                      state.isEasyViewEnabled 
                        ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                        : 'border-civic-blue-300 text-civic-blue-600'
                    )}
                  >
                    <Mic className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label className={cn(
                  'font-medium',
                  state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                )}>
                  Date of Birth *
                </Label>
                <Input
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => setFormData(prev => ({ ...prev, dateOfBirth: e.target.value }))}
                  className={cn(
                    errors.dateOfBirth && 'border-red-500',
                    state.isEasyViewEnabled 
                      ? 'bg-black border-yellow-400 text-yellow-400 text-lg' 
                      : 'border-civic-blue-300'
                  )}
                />
              </div>

              <div className="space-y-2">
                <Label className={cn(
                  'font-medium',
                  state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                )}>
                  Gender *
                </Label>
                <select
                  value={formData.gender}
                  onChange={(e) => setFormData(prev => ({ ...prev, gender: e.target.value }))}
                  className={cn(
                    'w-full p-2 rounded-md border',
                    errors.gender && 'border-red-500',
                    state.isEasyViewEnabled 
                      ? 'bg-black border-yellow-400 text-yellow-400 text-lg' 
                      : 'border-civic-blue-300'
                  )}
                >
                  <option value="">Select Gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div className="space-y-2">
                <Label className={cn(
                  'font-medium',
                  state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                )}>
                  Phone Number *
                </Label>
                <Input
                  type="tel"
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData(prev => ({ ...prev, phoneNumber: e.target.value.replace(/\D/g, '').slice(0, 10) }))}
                  placeholder="Enter 10-digit mobile number"
                  className={cn(
                    errors.phoneNumber && 'border-red-500',
                    state.isEasyViewEnabled 
                      ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                      : 'border-civic-blue-300'
                  )}
                  maxLength={10}
                />
              </div>

              <div className="space-y-2">
                <Label className={cn(
                  'font-medium',
                  state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                )}>
                  Email (Optional)
                </Label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="Enter email address"
                  className={cn(
                    state.isEasyViewEnabled 
                      ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                      : 'border-civic-blue-300'
                  )}
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Address Information */}
        {currentStep === 2 && (
          <div className="space-y-6">
            <h2 className={cn(
              'font-semibold text-center',
              state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
            )}>
              Step 2: Address & Document Information
            </h2>

            <div className="space-y-6">
              <div className="space-y-2">
                <Label className={cn(
                  'font-medium flex items-center gap-2',
                  state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                )}>
                  Full Address *
                </Label>
                <div className="flex gap-2">
                  <Textarea
                    value={formData.address}
                    onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                    placeholder="Enter your complete address"
                    rows={3}
                    className={cn(
                      'flex-1',
                      errors.address && 'border-red-500',
                      state.isEasyViewEnabled 
                        ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                        : 'border-civic-blue-300'
                    )}
                  />
                  <Button
                    onClick={() => handleVoiceInput('address')}
                    variant="outline"
                    size="icon"
                    className={cn(
                      'h-fit',
                      state.isEasyViewEnabled 
                        ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                        : 'border-civic-blue-300 text-civic-blue-600'
                    )}
                  >
                    <Mic className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className={cn(
                    'font-medium',
                    state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                  )}>
                    Pincode *
                  </Label>
                  <Input
                    value={formData.pincode}
                    onChange={(e) => setFormData(prev => ({ ...prev, pincode: e.target.value.replace(/\D/g, '').slice(0, 6) }))}
                    placeholder="Enter 6-digit pincode"
                    className={cn(
                      errors.pincode && 'border-red-500',
                      state.isEasyViewEnabled 
                        ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                        : 'border-civic-blue-300'
                    )}
                    maxLength={6}
                  />
                </div>

                <div className="space-y-2">
                  <Label className={cn(
                    'font-medium',
                    state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                  )}>
                    Aadhaar Number *
                  </Label>
                  <Input
                    value={formData.aadhaarNumber}
                    onChange={(e) => setFormData(prev => ({ ...prev, aadhaarNumber: e.target.value.replace(/\D/g, '').slice(0, 12) }))}
                    placeholder="Enter 12-digit Aadhaar number"
                    className={cn(
                      errors.aadhaarNumber && 'border-red-500',
                      state.isEasyViewEnabled 
                        ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                        : 'border-civic-blue-300'
                    )}
                    maxLength={12}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className={cn(
                  'font-medium',
                  state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                )}>
                  Constituency (Auto-detected from pincode)
                </Label>
                <Input
                  value="Central Delhi - Assembly Constituency 05"
                  disabled
                  className={cn(
                    state.isEasyViewEnabled 
                      ? 'bg-black border-yellow-400 text-yellow-400 text-lg' 
                      : 'border-civic-blue-300 bg-gray-50'
                  )}
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Document Upload */}
        {currentStep === 3 && (
          <div className="space-y-6">
            <h2 className={cn(
              'font-semibold text-center',
              state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
            )}>
              Step 3: Upload Required Documents
            </h2>

            <div className="space-y-4">
              {documents.map((doc, index) => (
                <Card key={index} className={cn(
                  'p-4 border-2',
                  doc.uploaded 
                    ? (state.isEasyViewEnabled ? 'border-yellow-400 bg-yellow-400/20' : 'border-civic-green-300 bg-civic-green-50')
                    : (state.isEasyViewEnabled ? 'border-yellow-600' : 'border-gray-300')
                )}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <FileText className={cn(
                        'w-6 h-6',
                        doc.uploaded 
                          ? (state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-green-600')
                          : (state.isEasyViewEnabled ? 'text-yellow-600' : 'text-gray-500')
                      )} />
                      <div>
                        <h4 className={cn(
                          'font-medium',
                          state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-800'
                        )}>
                          {doc.name} {doc.required && '*'}
                        </h4>
                        <p className={cn(
                          'text-sm',
                          state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                        )}>
                          {doc.uploaded ? 'Document uploaded successfully' : 'Click to upload document'}
                        </p>
                      </div>
                    </div>
                    
                    {doc.uploaded ? (
                      <CheckCircle className={cn(
                        'w-6 h-6',
                        state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-green-600'
                      )} />
                    ) : (
                      <Button
                        onClick={() => handleDocumentUpload(index)}
                        className={cn(
                          'flex items-center gap-2',
                          state.isEasyViewEnabled 
                            ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                            : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
                        )}
                      >
                        <Upload className="w-4 h-4" />
                        Upload
                      </Button>
                    )}
                  </div>
                </Card>
              ))}
            </div>

            <Card className={cn(
              'p-4 border-2',
              state.isEasyViewEnabled 
                ? 'bg-black border-yellow-400' 
                : 'bg-blue-50 border-blue-200'
            )}>
              <div className="flex items-start gap-3">
                <AlertCircle className={cn(
                  'w-6 h-6 mt-1',
                  state.isEasyViewEnabled ? 'text-yellow-400' : 'text-blue-600'
                )} />
                <div>
                  <h4 className={cn(
                    'font-medium mb-2',
                    state.isEasyViewEnabled ? 'text-yellow-400' : 'text-blue-800'
                  )}>
                    Document Requirements
                  </h4>
                  <ul className={cn(
                    'text-sm space-y-1',
                    state.isEasyViewEnabled ? 'text-yellow-300' : 'text-blue-700'
                  )}>
                    <li>• All documents should be clear and readable</li>
                    <li>• File size should not exceed 2MB per document</li>
                    <li>• Accepted formats: JPG, PNG, PDF</li>
                    <li>• Ensure all details are visible in the uploaded documents</li>
                  </ul>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex justify-between pt-6">
          <Button
            onClick={prevStep}
            disabled={currentStep === 1}
            variant="outline"
            className={cn(
              'flex items-center gap-2',
              state.isEasyViewEnabled 
                ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20 disabled:opacity-50' 
                : 'border-civic-blue-300 text-civic-blue-600 disabled:opacity-50'
            )}
          >
            Previous
          </Button>

          {currentStep < 3 ? (
            <Button
              onClick={nextStep}
              className={cn(
                'flex items-center gap-2',
                state.isEasyViewEnabled 
                  ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                  : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
              )}
            >
              Next Step
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={isSubmitting}
              className={cn(
                'flex items-center gap-2',
                state.isEasyViewEnabled 
                  ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                  : 'bg-civic-green-600 text-white hover:bg-civic-green-700'
              )}
            >
              {isSubmitting ? (
                <>
                  <Send className="w-4 h-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Submit Application
                </>
              )}
            </Button>
          )}
        </div>
      </Card>

      {/* Help Section */}
      <Card className={cn(
        'p-6 border-2',
        state.isEasyViewEnabled 
          ? 'bg-black border-yellow-400' 
          : 'bg-civic-blue-50 border-civic-blue-200'
      )}>
        <div className="space-y-4">
          <h3 className={cn(
            'font-semibold',
            state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-civic-blue-800'
          )}>
            Need Help?
          </h3>
          <p className={cn(
            state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
          )}>
            Use voice input for easy form filling, or contact our support team for assistance.
          </p>
          <div className="flex flex-col sm:flex-row gap-3">
            <Button className={cn(
              'flex items-center gap-2',
              state.isEasyViewEnabled 
                ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
            )}>
              <Phone className="w-4 h-4" />
              Call Support: 1800-XXX-XXXX
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
