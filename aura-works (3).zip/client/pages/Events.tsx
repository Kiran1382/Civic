import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { readAloud } from '@/lib/accessibility';
import { 
  Calendar,
  MapPin,
  Clock,
  Users,
  Volume2,
  Heart,
  Search,
  Mic,
  Filter,
  CheckCircle,
  Star,
  Navigation
} from 'lucide-react';

const eventCategories = [
  { id: 'all', name: 'All Events', icon: '📅' },
  { id: 'health', name: 'Health & Wellness', icon: '🏥' },
  { id: 'social', name: 'Social Gatherings', icon: '🤝' },
  { id: 'education', name: 'Educational', icon: '📚' },
  { id: 'civic', name: 'Civic Meetings', icon: '🏛️' },
  { id: 'cultural', name: 'Cultural Events', icon: '🎭' }
];

const upcomingEvents = [
  {
    id: 1,
    title: 'Senior Citizens Health Camp',
    category: 'health',
    date: '2024-01-15',
    time: '09:00 AM - 02:00 PM',
    location: 'Community Health Center, Sector 12',
    distance: '1.2 km',
    organizer: 'Municipal Health Department',
    description: 'Free health checkups, eye screening, and consultation with doctors. Medicine distribution for common ailments.',
    attendees: 45,
    isInterested: false,
    tags: ['Free', 'Healthcare', 'Senior Friendly']
  },
  {
    id: 2,
    title: 'Voter Awareness Workshop',
    category: 'civic',
    date: '2024-01-18',
    time: '10:00 AM - 12:00 PM',
    location: 'City Hall Auditorium',
    distance: '2.5 km',
    organizer: 'Election Commission',
    description: 'Learn about voting procedures, candidate information, and your voting rights. Q&A session included.',
    attendees: 78,
    isInterested: true,
    tags: ['Educational', 'Civic Duty', 'Important']
  },
  {
    id: 3,
    title: 'Cultural Evening - Classical Music',
    category: 'cultural',
    date: '2024-01-20',
    time: '06:00 PM - 08:00 PM',
    location: 'Community Center Amphitheater',
    distance: '0.8 km',
    organizer: 'Cultural Society',
    description: 'Evening of classical music performances by local artists. Light refreshments provided.',
    attendees: 32,
    isInterested: false,
    tags: ['Music', 'Entertainment', 'Community']
  },
  {
    id: 4,
    title: 'Digital Literacy Workshop',
    category: 'education',
    date: '2024-01-22',
    time: '02:00 PM - 04:00 PM',
    location: 'Public Library, Main Branch',
    distance: '1.8 km',
    organizer: 'Digital India Initiative',
    description: 'Learn basic smartphone usage, online government services, and digital payments. Hands-on training provided.',
    attendees: 28,
    isInterested: false,
    tags: ['Technology', 'Learning', 'Free']
  },
  {
    id: 5,
    title: 'Community Garden Meeting',
    category: 'social',
    date: '2024-01-25',
    time: '04:00 PM - 05:30 PM',
    location: 'Neighborhood Park',
    distance: '0.5 km',
    organizer: 'Residents Association',
    description: 'Planning session for community garden project. Discussion on plant selection and maintenance schedule.',
    attendees: 19,
    isInterested: true,
    tags: ['Gardening', 'Community', 'Planning']
  }
];

export default function Events() {
  const { state } = useAccessibility();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [events, setEvents] = useState(upcomingEvents);
  const [isVoiceSearching, setIsVoiceSearching] = useState(false);

  const handleReadAloud = (text: string) => {
    readAloud(text);
  };

  const toggleInterest = (eventId: number) => {
    const updatedEvents = events.map(event => {
      if (event.id === eventId) {
        const newInterest = !event.isInterested;
        readAloud(
          newInterest 
            ? `Marked interest in ${event.title}. You will receive reminders.`
            : `Removed interest from ${event.title}.`
        );
        return { ...event, isInterested: newInterest };
      }
      return event;
    });
    setEvents(updatedEvents);
  };

  const handleVoiceSearch = () => {
    setIsVoiceSearching(true);
    readAloud('Voice search activated. Say something like "Show events near me" or "Find health events".');
    
    // Simulate voice recognition
    setTimeout(() => {
      setIsVoiceSearching(false);
      setSearchQuery('health events');
      readAloud('Voice search completed. Showing health events.');
    }, 3000);
  };

  const filteredEvents = events.filter(event => {
    const matchesCategory = selectedCategory === 'all' || event.category === selectedCategory;
    const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={cn(
        'text-center space-y-4 p-6 rounded-xl',
        state.isEasyViewEnabled 
          ? 'bg-black text-yellow-400' 
          : 'bg-white border border-civic-blue-200'
      )}>
        <div className="flex items-center justify-center gap-3">
          <Calendar className={cn(
            'w-10 h-10',
            state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
          )} />
          <h1 className={cn(
            'font-bold',
            state.isEasyViewEnabled ? 'text-3xl' : 'text-2xl text-gray-800'
          )}>
            Community Events
          </h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleReadAloud('Community Events. Discover local events, town halls, and community meetings happening near you.')}
            className={cn(
              'h-8 w-8 p-0',
              state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
            )}
          >
            <Volume2 className="w-4 h-4" />
          </Button>
        </div>
        <p className={cn(
          'max-w-2xl mx-auto leading-relaxed',
          state.isEasyViewEnabled ? 'text-xl text-yellow-300' : 'text-gray-600'
        )}>
          Discover local events, town halls, and community meetings happening near you
        </p>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4">
        {/* Search Bar */}
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className={cn(
              'absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5',
              state.isEasyViewEnabled ? 'text-yellow-600' : 'text-gray-400'
            )} />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search events by name, type, or keywords..."
              className={cn(
                'pl-10',
                state.isEasyViewEnabled 
                  ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                  : 'border-civic-blue-300'
              )}
            />
          </div>
          <Button
            onClick={handleVoiceSearch}
            disabled={isVoiceSearching}
            className={cn(
              'flex items-center gap-2',
              isVoiceSearching 
                ? (state.isEasyViewEnabled ? 'bg-red-600 text-white' : 'bg-red-500 text-white')
                : (state.isEasyViewEnabled ? 'bg-yellow-400 text-black hover:bg-yellow-500' : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700')
            )}
          >
            <Mic className="w-4 h-4" />
            {isVoiceSearching ? 'Listening...' : 'Voice Search'}
          </Button>
        </div>

        {/* Category Filters */}
        <div className="flex overflow-x-auto gap-2 pb-2">
          {eventCategories.map((category) => (
            <Button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              variant={selectedCategory === category.id ? "default" : "outline"}
              className={cn(
                'flex items-center gap-2 whitespace-nowrap',
                selectedCategory === category.id
                  ? (state.isEasyViewEnabled ? 'bg-yellow-400 text-black' : 'bg-civic-blue-600 text-white')
                  : (state.isEasyViewEnabled ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' : 'border-civic-blue-300 text-civic-blue-600')
              )}
            >
              <span>{category.icon}</span>
              <span>{category.name}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Events List */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className={cn(
            'font-semibold',
            state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
          )}>
            {selectedCategory === 'all' ? 'All Events' : eventCategories.find(c => c.id === selectedCategory)?.name} 
            ({filteredEvents.length})
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleReadAloud(`Found ${filteredEvents.length} events matching your criteria.`)}
            className={cn(
              'h-8 w-8 p-0',
              state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
            )}
          >
            <Volume2 className="w-4 h-4" />
          </Button>
        </div>

        {filteredEvents.length === 0 ? (
          <Card className={cn(
            'p-8 text-center border-2',
            state.isEasyViewEnabled 
              ? 'bg-black border-yellow-400' 
              : 'bg-gray-50 border-gray-200'
          )}>
            <Calendar className={cn(
              'w-12 h-12 mx-auto mb-4',
              state.isEasyViewEnabled ? 'text-yellow-600' : 'text-gray-400'
            )} />
            <h3 className={cn(
              'font-semibold mb-2',
              state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-gray-600'
            )}>
              No Events Found
            </h3>
            <p className={cn(
              state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-500'
            )}>
              Try adjusting your search or category filter to find more events.
            </p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredEvents.map((event) => (
              <Card 
                key={event.id}
                className={cn(
                  'p-6 transition-all duration-300 hover:scale-105 border-2',
                  state.isEasyViewEnabled 
                    ? 'bg-black border-yellow-400' 
                    : 'bg-white border-civic-blue-200 hover:border-civic-blue-400 hover:shadow-lg'
                )}
              >
                <div className="space-y-4">
                  {/* Event Header */}
                  <div className="flex items-start justify-between">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2">
                        <h3 className={cn(
                          'font-semibold leading-tight',
                          state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-gray-800'
                        )}>
                          {event.title}
                        </h3>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleReadAloud(`${event.title}. ${event.description}. Date: ${formatDate(event.date)}. Time: ${event.time}. Location: ${event.location}.`)}
                          className={cn(
                            'h-6 w-6 p-0',
                            state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-500'
                          )}
                        >
                          <Volume2 className="w-3 h-3" />
                        </Button>
                      </div>
                      <p className={cn(
                        'text-sm',
                        state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                      )}>
                        Organized by {event.organizer}
                      </p>
                    </div>
                    
                    <Button
                      onClick={() => toggleInterest(event.id)}
                      variant={event.isInterested ? "default" : "outline"}
                      size="sm"
                      className={cn(
                        'flex items-center gap-1 ml-2',
                        event.isInterested
                          ? (state.isEasyViewEnabled ? 'bg-yellow-400 text-black' : 'bg-civic-green-600 text-white')
                          : (state.isEasyViewEnabled ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' : 'border-civic-blue-300 text-civic-blue-600')
                      )}
                    >
                      {event.isInterested ? <CheckCircle className="w-4 h-4" /> : <Heart className="w-4 h-4" />}
                      {event.isInterested ? 'Interested' : 'Mark Interest'}
                    </Button>
                  </div>

                  {/* Event Details */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                    <div className={cn(
                      'flex items-center gap-2',
                      state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                    )}>
                      <Calendar className="w-4 h-4 flex-shrink-0" />
                      <span>{formatDate(event.date)}</span>
                    </div>
                    
                    <div className={cn(
                      'flex items-center gap-2',
                      state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                    )}>
                      <Clock className="w-4 h-4 flex-shrink-0" />
                      <span>{event.time}</span>
                    </div>
                    
                    <div className={cn(
                      'flex items-center gap-2',
                      state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                    )}>
                      <MapPin className="w-4 h-4 flex-shrink-0" />
                      <span>{event.location}</span>
                    </div>
                    
                    <div className={cn(
                      'flex items-center gap-2',
                      state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                    )}>
                      <Navigation className="w-4 h-4 flex-shrink-0" />
                      <span>{event.distance} away</span>
                    </div>
                  </div>

                  {/* Description */}
                  <p className={cn(
                    'leading-relaxed',
                    state.isEasyViewEnabled ? 'text-lg text-yellow-300' : 'text-gray-600'
                  )}>
                    {event.description}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2">
                    {event.tags.map((tag, index) => (
                      <span
                        key={index}
                        className={cn(
                          'px-2 py-1 rounded-full text-xs font-medium',
                          state.isEasyViewEnabled 
                            ? 'bg-yellow-400/20 text-yellow-400 border border-yellow-400' 
                            : 'bg-civic-blue-100 text-civic-blue-700'
                        )}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* Attendees */}
                  <div className={cn(
                    'flex items-center gap-2 text-sm',
                    state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                  )}>
                    <Users className="w-4 h-4" />
                    <span>{event.attendees} people interested</span>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Voice Commands Help */}
      <Card className={cn(
        'p-6 border-2',
        state.isEasyViewEnabled 
          ? 'bg-black border-yellow-400' 
          : 'bg-civic-blue-50 border-civic-blue-200'
      )}>
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <Mic className={cn(
              'w-6 h-6',
              state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
            )} />
            <h3 className={cn(
              'font-semibold',
              state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-civic-blue-800'
            )}>
              Voice Commands You Can Use
            </h3>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              '"Show events near me"',
              '"Find health events"',
              '"What\'s happening this week?"',
              '"Show cultural events"',
              '"Events in community center"',
              '"Next event"'
            ].map((command, index) => (
              <div 
                key={index}
                className={cn(
                  'p-3 rounded-lg border',
                  state.isEasyViewEnabled 
                    ? 'border-yellow-400 bg-yellow-400/10' 
                    : 'border-civic-blue-200 bg-white'
                )}
              >
                <span className={cn(
                  'font-mono text-sm',
                  state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
                )}>
                  {command}
                </span>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}
