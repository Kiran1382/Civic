import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { readAloud } from '@/lib/accessibility';
import { useNavigate } from 'react-router-dom';
import { 
  Globe,
  Volume2,
  Play,
  CheckCircle,
  ArrowRight,
  Heart,
  Users,
  Vote,
  Mic
} from 'lucide-react';

const languages = [
  {
    code: 'en',
    name: 'English',
    nativeName: 'English',
    greeting: 'Welcome to Civic Connect!'
  },
  {
    code: 'hi',
    name: 'Hindi',
    nativeName: 'हिंदी',
    greeting: 'सिविक कनेक्ट में आपका स्वागत है!'
  },
  {
    code: 'te',
    name: 'Telugu',
    nativeName: 'తెలుగు',
    greeting: 'సివిక్ కనెక్ట్‌కు స్వాగతం!'
  }
];

const onboardingSteps = [
  {
    id: 1,
    title: "Welcome to Civic Connect",
    description: "Your gateway to government services and community participation. This app is designed especially for senior citizens with easy-to-use features.",
    icon: <Heart className="w-12 h-12" />
  },
  {
    id: 2,
    title: "Voice & Touch Features",
    description: "Use voice commands, touch-to-read, and text-to-speech features. Everything can be read aloud and controlled by voice.",
    icon: <Mic className="w-12 h-12" />
  },
  {
    id: 3,
    title: "Community Services",
    description: "Access voting help, report local issues, find community events, and stay updated with government news.",
    icon: <Users className="w-12 h-12" />
  },
  {
    id: 4,
    title: "Your Voice Matters",
    description: "Participate in policy feedback, register to vote, and make your voice heard in your community.",
    icon: <Vote className="w-12 h-12" />
  }
];

export default function Onboarding() {
  const { state } = useAccessibility();
  const navigate = useNavigate();
  const [selectedLanguage, setSelectedLanguage] = useState<string>('en');
  const [currentStep, setCurrentStep] = useState(0);
  const [showSteps, setShowSteps] = useState(false);

  const handleReadAloud = (text: string) => {
    readAloud(text);
  };

  const handleLanguageSelect = (langCode: string, language: any) => {
    setSelectedLanguage(langCode);
    readAloud(`${language.greeting} Language selected: ${language.name}`);
  };

  const playVoiceIntro = () => {
    const introText = `Welcome to Civic Connect! This app helps senior citizens engage with government services easily. 
    You can use voice commands, touch any text to read it aloud, and switch to easy view mode for better visibility. 
    Choose your preferred language and let's get started with making civic participation simple and accessible.`;
    readAloud(introText);
  };

  const startOnboarding = () => {
    setShowSteps(true);
    readAloud("Starting onboarding tour. Learn about all the features available in Civic Connect.");
  };

  const nextStep = () => {
    if (currentStep < onboardingSteps.length - 1) {
      const newStep = currentStep + 1;
      setCurrentStep(newStep);
      readAloud(`Step ${newStep + 1}: ${onboardingSteps[newStep].title}. ${onboardingSteps[newStep].description}`);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      const newStep = currentStep - 1;
      setCurrentStep(newStep);
      readAloud(`Step ${newStep + 1}: ${onboardingSteps[newStep].title}. ${onboardingSteps[newStep].description}`);
    }
  };

  const completeOnboarding = () => {
    readAloud("Onboarding complete! Welcome to Civic Connect. Redirecting to dashboard.");
    setTimeout(() => {
      navigate('/dashboard');
    }, 2000);
  };

  if (showSteps) {
    const currentStepData = onboardingSteps[currentStep];
    
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className={cn(
          'w-full max-w-2xl p-8 text-center space-y-8 border-2',
          state.isEasyViewEnabled 
            ? 'bg-black border-yellow-400' 
            : 'bg-white border-civic-blue-200 shadow-xl'
        )}>
          {/* Progress Indicator */}
          <div className="flex justify-center space-x-2">
            {onboardingSteps.map((_, index) => (
              <div
                key={index}
                className={cn(
                  'w-3 h-3 rounded-full transition-all duration-300',
                  index <= currentStep 
                    ? (state.isEasyViewEnabled ? 'bg-yellow-400' : 'bg-civic-blue-500')
                    : (state.isEasyViewEnabled ? 'bg-yellow-800' : 'bg-gray-300')
                )}
              />
            ))}
          </div>

          {/* Step Content */}
          <div className="space-y-6">
            <div className={cn(
              'w-20 h-20 mx-auto rounded-full flex items-center justify-center',
              state.isEasyViewEnabled 
                ? 'bg-yellow-400 text-black' 
                : 'bg-civic-blue-100 text-civic-blue-600'
            )}>
              {currentStepData.icon}
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-center gap-3">
                <h1 className={cn(
                  'font-bold',
                  state.isEasyViewEnabled ? 'text-3xl text-yellow-400' : 'text-2xl text-gray-800'
                )}>
                  {currentStepData.title}
                </h1>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleReadAloud(`${currentStepData.title}. ${currentStepData.description}`)}
                  className={cn(
                    'h-8 w-8 p-0',
                    state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
                  )}
                >
                  <Volume2 className="w-4 h-4" />
                </Button>
              </div>
              
              <p className={cn(
                'max-w-lg mx-auto leading-relaxed',
                state.isEasyViewEnabled ? 'text-xl text-yellow-300' : 'text-lg text-gray-600'
              )}>
                {currentStepData.description}
              </p>
            </div>
          </div>

          {/* Navigation Buttons */}
          <div className="flex justify-between items-center">
            <Button
              onClick={prevStep}
              disabled={currentStep === 0}
              variant="outline"
              className={cn(
                'flex items-center gap-2',
                state.isEasyViewEnabled 
                  ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20 disabled:opacity-50' 
                  : 'border-civic-blue-300 text-civic-blue-600 disabled:opacity-50'
              )}
            >
              Previous
            </Button>

            <div className={cn(
              'text-sm',
              state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-500'
            )}>
              {currentStep + 1} of {onboardingSteps.length}
            </div>

            {currentStep === onboardingSteps.length - 1 ? (
              <Button
                onClick={completeOnboarding}
                className={cn(
                  'flex items-center gap-2',
                  state.isEasyViewEnabled 
                    ? 'bg-yellow-400 text-black hover:bg-yellow-500 text-lg px-8' 
                    : 'bg-civic-green-600 text-white hover:bg-civic-green-700'
                )}
              >
                <CheckCircle className="w-5 h-5" />
                Get Started
              </Button>
            ) : (
              <Button
                onClick={nextStep}
                className={cn(
                  'flex items-center gap-2',
                  state.isEasyViewEnabled 
                    ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                    : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
                )}
              >
                Next
                <ArrowRight className="w-4 h-4" />
              </Button>
            )}
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className={cn(
        'text-center space-y-6 p-8 rounded-xl',
        state.isEasyViewEnabled 
          ? 'bg-black text-yellow-400' 
          : 'bg-gradient-to-br from-civic-blue-50 to-civic-green-50 border border-civic-blue-200'
      )}>
        <div className={cn(
          'w-20 h-20 mx-auto rounded-full flex items-center justify-center',
          state.isEasyViewEnabled 
            ? 'bg-yellow-400 text-black' 
            : 'bg-civic-blue-100 text-civic-blue-600'
        )}>
          <Globe className="w-10 h-10" />
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-center gap-3">
            <h1 className={cn(
              'font-bold',
              state.isEasyViewEnabled ? 'text-4xl' : 'text-3xl text-gray-800'
            )}>
              Welcome to Civic Connect
            </h1>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleReadAloud('Welcome to Civic Connect. Your gateway to government services and community participation.')}
              className={cn(
                'h-8 w-8 p-0',
                state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
              )}
            >
              <Volume2 className="w-5 h-5" />
            </Button>
          </div>
          
          <p className={cn(
            'max-w-2xl mx-auto leading-relaxed',
            state.isEasyViewEnabled ? 'text-2xl text-yellow-300' : 'text-xl text-gray-600'
          )}>
            Your gateway to government services and community participation
          </p>

          <Button
            onClick={playVoiceIntro}
            className={cn(
              'flex items-center gap-2 mx-auto transition-all duration-300',
              state.isEasyViewEnabled 
                ? 'bg-yellow-400 text-black hover:bg-yellow-500 text-lg px-8 py-4' 
                : 'bg-civic-green-600 text-white hover:bg-civic-green-700'
            )}
          >
            <Play className="w-5 h-5" />
            Play Voice Introduction
          </Button>
        </div>
      </div>

      {/* Language Selection */}
      <div className="space-y-6">
        <div className="text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <h2 className={cn(
              'font-semibold',
              state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
            )}>
              Choose Your Language
            </h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleReadAloud('Choose Your Language. Select your preferred language for the app.')}
              className={cn(
                'h-8 w-8 p-0',
                state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
              )}
            >
              <Volume2 className="w-4 h-4" />
            </Button>
          </div>
          <p className={cn(
            state.isEasyViewEnabled ? 'text-lg text-yellow-300' : 'text-gray-600'
          )}>
            आपकी भाषा चुनें / మీ భాషను ఎంచుకోండి / Choose your language
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {languages.map((language) => (
            <Card 
              key={language.code}
              className={cn(
                'p-6 cursor-pointer transition-all duration-300 border-2 hover:scale-105',
                selectedLanguage === language.code 
                  ? (state.isEasyViewEnabled ? 'border-yellow-400 bg-yellow-400/20' : 'border-civic-blue-500 bg-civic-blue-50')
                  : (state.isEasyViewEnabled ? 'border-yellow-600 bg-black' : 'border-civic-blue-200 bg-white')
              )}
              onClick={() => handleLanguageSelect(language.code, language)}
            >
              <div className="text-center space-y-4">
                <div className="text-4xl">
                  {language.code === 'en' && '🇺🇸'}
                  {language.code === 'hi' && '🇮🇳'}
                  {language.code === 'te' && '🇮🇳'}
                </div>
                
                <div className="space-y-2">
                  <h3 className={cn(
                    'font-semibold text-lg',
                    state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-800'
                  )}>
                    {language.nativeName}
                  </h3>
                  <p className={cn(
                    'text-sm',
                    state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                  )}>
                    {language.name}
                  </p>
                  <p className={cn(
                    'text-sm font-medium',
                    state.isEasyViewEnabled ? 'text-yellow-200' : 'text-civic-blue-700'
                  )}>
                    "{language.greeting}"
                  </p>
                </div>

                <div className="flex items-center justify-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleReadAloud(`${language.name}. ${language.greeting}`);
                    }}
                    className={cn(
                      'h-8 w-8 p-0',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
                    )}
                  >
                    <Volume2 className="w-4 h-4" />
                  </Button>
                  
                  {selectedLanguage === language.code && (
                    <CheckCircle className={cn(
                      'w-6 h-6',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-green-600'
                    )} />
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Continue Section */}
      <Card className={cn(
        'p-8 text-center border-2',
        state.isEasyViewEnabled 
          ? 'bg-black border-yellow-400' 
          : 'bg-civic-green-50 border-civic-green-200'
      )}>
        <div className="space-y-6">
          <h3 className={cn(
            'font-semibold',
            state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-civic-green-800'
          )}>
            Ready to Get Started?
          </h3>
          
          <p className={cn(
            'max-w-lg mx-auto',
            state.isEasyViewEnabled ? 'text-lg text-yellow-300' : 'text-civic-green-700'
          )}>
            Take a quick tour to learn about all the accessibility features and services available to you.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={startOnboarding}
              className={cn(
                'flex items-center gap-2 transition-all duration-300',
                state.isEasyViewEnabled 
                  ? 'bg-yellow-400 text-black hover:bg-yellow-500 text-lg px-8 py-4' 
                  : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
              )}
            >
              <Play className="w-5 h-5" />
              Start Tour
            </Button>
            
            <Button
              onClick={() => navigate('/dashboard')}
              variant="outline"
              className={cn(
                'flex items-center gap-2',
                state.isEasyViewEnabled 
                  ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20 text-lg px-8 py-4' 
                  : 'border-civic-green-300 text-civic-green-600'
              )}
            >
              Skip Tour
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
