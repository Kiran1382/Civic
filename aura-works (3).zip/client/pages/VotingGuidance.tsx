import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { readAloud, handleTouchToRead } from '@/lib/accessibility';
import { 
  Vote,
  MapPin,
  Clock,
  CheckCircle,
  FileText,
  Volume2,
  Navigation,
  Play,
  Users,
  Shield,
  AlertCircle
} from 'lucide-react';

const votingSteps = [
  {
    id: 1,
    title: "Before You Go",
    description: "Bring valid ID (voter ID, Aadhaar, or passport), check your polling station location, and verify your name on the voter list.",
    icon: <Shield className="w-8 h-8" />,
    details: [
      "Valid photo ID is mandatory",
      "Check polling station timings (7 AM to 6 PM)",
      "Wear comfortable clothes and carry water",
      "Check weather conditions"
    ]
  },
  {
    id: 2,
    title: "At the Polling Station",
    description: "Queue in the correct line, show your ID to the officer, and get your finger marked with indelible ink.",
    icon: <Users className="w-8 h-8" />,
    details: [
      "Join the appropriate queue (men/women/senior citizens)",
      "Maintain social distancing",
      "Show ID to the first officer",
      "Get your finger marked with ink",
      "Sign or put thumbprint on register"
    ]
  },
  {
    id: 3,
    title: "Using the EVM",
    description: "Press the button next to your chosen candidate's name and symbol. The EVM will beep and a light will show your vote is recorded.",
    icon: <Vote className="w-8 h-8" />,
    details: [
      "Look for your candidate's name and symbol",
      "Press the button firmly once",
      "Wait for the beep and light confirmation",
      "Do not press multiple buttons",
      "Ask for help if needed"
    ]
  },
  {
    id: 4,
    title: "After Voting",
    description: "Exit through the designated path and keep your voter slip safe. Your civic duty is complete!",
    icon: <CheckCircle className="w-8 h-8" />,
    details: [
      "Keep your voter slip safe",
      "Exit through the marked exit",
      "Do not discuss your vote publicly",
      "Share voting experience positively",
      "Encourage others to vote"
    ]
  }
];

const sampleCandidates = [
  { name: "Candidate A", party: "Party 1", symbol: "🏠" },
  { name: "Candidate B", party: "Party 2", symbol: "🌸" },
  { name: "Candidate C", party: "Party 3", symbol: "⭐" },
  { name: "NOTA", party: "None of the Above", symbol: "❌" }
];

export default function VotingGuidance() {
  const { state } = useAccessibility();
  const [currentStep, setCurrentStep] = useState(0);
  const [showBallotPractice, setShowBallotPractice] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState<number | null>(null);
  const [voterAddress, setVoterAddress] = useState('');
  const [showBoothFinder, setShowBoothFinder] = useState(false);

  const handleReadAloud = (text: string) => {
    readAloud(text);
  };

  const handleStepClick = (step: any, index: number) => {
    setCurrentStep(index);
    if (state.isTouchToReadEnabled) {
      readAloud(`Step ${step.id}: ${step.title}. ${step.description}`);
    }
  };

  const handleBallotPractice = () => {
    setShowBallotPractice(true);
    readAloud('Sample ballot practice started. Choose a candidate to practice voting.');
  };

  const handleCandidateSelect = (index: number, candidate: any) => {
    setSelectedCandidate(index);
    readAloud(`You selected ${candidate.name} from ${candidate.party}. In a real election, this would be your final vote.`);
  };

  const handleVoiceHelp = () => {
    readAloud('Voice help activated. You can say: Next step, Previous step, Practice ballot, Find my booth, or Help.');
  };

  const findPollingBooth = () => {
    setShowBoothFinder(true);
    readAloud('Polling booth finder opened. Enter your address to find your assigned polling station.');
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={cn(
        'text-center space-y-4 p-6 rounded-xl',
        state.isEasyViewEnabled 
          ? 'bg-black text-yellow-400' 
          : 'bg-white border border-civic-blue-200'
      )}>
        <div className="flex items-center justify-center gap-3">
          <Vote className={cn(
            'w-10 h-10',
            state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
          )} />
          <h1 className={cn(
            'font-bold',
            state.isEasyViewEnabled ? 'text-3xl' : 'text-2xl text-gray-800'
          )}>
            Voting Guidance
          </h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleReadAloud('Voting Guidance. Learn how to vote step by step with practice tools and polling booth finder.')}
            className={cn(
              'h-8 w-8 p-0',
              state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
            )}
            aria-label="Read page title"
          >
            <Volume2 className="w-4 h-4" />
          </Button>
        </div>
        <p className={cn(
          'max-w-2xl mx-auto leading-relaxed',
          state.isEasyViewEnabled ? 'text-xl text-yellow-300' : 'text-gray-600'
        )}>
          Learn how to vote step by step with practice tools and polling booth finder
        </p>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Button
          onClick={handleBallotPractice}
          className={cn(
            'h-20 flex flex-col gap-2 transition-all duration-300',
            state.isEasyViewEnabled 
              ? 'bg-yellow-400 text-black hover:bg-yellow-500 text-lg' 
              : 'bg-civic-green-600 text-white hover:bg-civic-green-700'
          )}
        >
          <FileText className="w-6 h-6" />
          <span>Practice Ballot</span>
        </Button>
        
        <Button
          onClick={findPollingBooth}
          className={cn(
            'h-20 flex flex-col gap-2 transition-all duration-300',
            state.isEasyViewEnabled 
              ? 'bg-yellow-400 text-black hover:bg-yellow-500 text-lg' 
              : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
          )}
        >
          <MapPin className="w-6 h-6" />
          <span>Find My Booth</span>
        </Button>
        
        <Button
          onClick={handleVoiceHelp}
          className={cn(
            'h-20 flex flex-col gap-2 transition-all duration-300',
            state.isEasyViewEnabled 
              ? 'bg-yellow-400 text-black hover:bg-yellow-500 text-lg' 
              : 'bg-civic-green-500 text-white hover:bg-civic-green-600'
          )}
        >
          <Play className="w-6 h-6" />
          <span>Voice Help</span>
        </Button>
      </div>

      {/* Voting Steps */}
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <h2 className={cn(
            'font-semibold',
            state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
          )}>
            How to Vote - Step by Step
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleReadAloud('How to Vote - Step by Step guide')}
            className={cn(
              'h-8 w-8 p-0',
              state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
            )}
          >
            <Volume2 className="w-4 h-4" />
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {votingSteps.map((step, index) => (
            <Card 
              key={step.id}
              className={cn(
                'p-6 cursor-pointer transition-all duration-300 border-2',
                currentStep === index 
                  ? (state.isEasyViewEnabled ? 'border-yellow-400 bg-black' : 'border-civic-blue-500 bg-civic-blue-50')
                  : (state.isEasyViewEnabled ? 'border-yellow-600 bg-black' : 'border-civic-blue-200 bg-white'),
                'hover:scale-105'
              )}
              onClick={() => handleStepClick(step, index)}
            >
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className={cn(
                    'flex-shrink-0 p-3 rounded-xl',
                    state.isEasyViewEnabled 
                      ? 'bg-yellow-400 text-black' 
                      : 'bg-civic-blue-100 text-civic-blue-600'
                  )}>
                    {step.icon}
                  </div>
                  
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-2">
                      <h3 className={cn(
                        'font-semibold',
                        state.isEasyViewEnabled 
                          ? 'text-xl text-yellow-400' 
                          : 'text-lg text-gray-800'
                      )}>
                        Step {step.id}: {step.title}
                      </h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleReadAloud(`Step ${step.id}: ${step.title}. ${step.description}`);
                        }}
                        className={cn(
                          'h-6 w-6 p-0',
                          state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-500'
                        )}
                      >
                        <Volume2 className="w-3 h-3" />
                      </Button>
                    </div>
                    <p className={cn(
                      'leading-relaxed',
                      state.isEasyViewEnabled 
                        ? 'text-lg text-yellow-300' 
                        : 'text-gray-600'
                    )}>
                      {step.description}
                    </p>
                  </div>
                </div>

                {currentStep === index && (
                  <div className="mt-4 space-y-2">
                    <h4 className={cn(
                      'font-medium',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-800'
                    )}>
                      Detailed Instructions:
                    </h4>
                    <ul className="space-y-1">
                      {step.details.map((detail, detailIndex) => (
                        <li 
                          key={detailIndex}
                          className={cn(
                            'flex items-start gap-2',
                            state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                          )}
                        >
                          <CheckCircle className="w-4 h-4 mt-0.5 text-civic-green-500 flex-shrink-0" />
                          <span>{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Sample Ballot Practice */}
      {showBallotPractice && (
        <Card className={cn(
          'p-6 border-2',
          state.isEasyViewEnabled 
            ? 'bg-black border-yellow-400' 
            : 'bg-civic-green-50 border-civic-green-300'
        )}>
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <FileText className={cn(
                'w-8 h-8',
                state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-green-600'
              )} />
              <h3 className={cn(
                'font-semibold',
                state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-civic-green-800'
              )}>
                Sample Ballot Practice
              </h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleReadAloud('Sample Ballot Practice. Choose a candidate to practice voting with the electronic voting machine.')}
                className={cn(
                  'h-6 w-6 p-0',
                  state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-green-600'
                )}
              >
                <Volume2 className="w-3 h-3" />
              </Button>
            </div>

            <div className="space-y-4">
              <p className={cn(
                'text-center',
                state.isEasyViewEnabled ? 'text-lg text-yellow-300' : 'text-civic-green-700'
              )}>
                Practice voting by selecting a candidate below (this is just for practice)
              </p>

              <div className="grid gap-3">
                {sampleCandidates.map((candidate, index) => (
                  <Card 
                    key={index}
                    className={cn(
                      'p-4 cursor-pointer transition-all duration-300 border-2',
                      selectedCandidate === index 
                        ? (state.isEasyViewEnabled ? 'border-yellow-400 bg-yellow-400/20' : 'border-civic-blue-500 bg-civic-blue-100')
                        : (state.isEasyViewEnabled ? 'border-yellow-600' : 'border-gray-300'),
                      'hover:scale-102'
                    )}
                    onClick={() => handleCandidateSelect(index, candidate)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="text-3xl">{candidate.symbol}</div>
                        <div>
                          <h4 className={cn(
                            'font-medium',
                            state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-800'
                          )}>
                            {candidate.name}
                          </h4>
                          <p className={cn(
                            'text-sm',
                            state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                          )}>
                            {candidate.party}
                          </p>
                        </div>
                      </div>
                      <Button
                        variant={selectedCandidate === index ? "default" : "outline"}
                        className={cn(
                          'ml-4',
                          state.isEasyViewEnabled && selectedCandidate === index
                            ? 'bg-yellow-400 text-black'
                            : ''
                        )}
                      >
                        {selectedCandidate === index ? 'Selected' : 'Select'}
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>

              {selectedCandidate !== null && (
                <div className={cn(
                  'text-center p-4 rounded-lg',
                  state.isEasyViewEnabled 
                    ? 'bg-yellow-400/20 border border-yellow-400' 
                    : 'bg-civic-green-100 border border-civic-green-300'
                )}>
                  <CheckCircle className={cn(
                    'w-8 h-8 mx-auto mb-2',
                    state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-green-600'
                  )} />
                  <p className={cn(
                    'font-medium',
                    state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-civic-green-800'
                  )}>
                    Vote Recorded! 
                  </p>
                  <p className={cn(
                    'text-sm',
                    state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-green-700'
                  )}>
                    You selected {sampleCandidates[selectedCandidate].name}
                  </p>
                </div>
              )}
            </div>
          </div>
        </Card>
      )}

      {/* Polling Booth Finder */}
      {showBoothFinder && (
        <Card className={cn(
          'p-6 border-2',
          state.isEasyViewEnabled 
            ? 'bg-black border-yellow-400' 
            : 'bg-civic-blue-50 border-civic-blue-300'
        )}>
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <MapPin className={cn(
                'w-8 h-8',
                state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
              )} />
              <h3 className={cn(
                'font-semibold',
                state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-civic-blue-800'
              )}>
                Find Your Polling Booth
              </h3>
            </div>

            <div className="space-y-4">
              <div>
                <Label className={cn(
                  'font-medium',
                  state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                )}>
                  Enter Your Address
                </Label>
                <Input
                  value={voterAddress}
                  onChange={(e) => setVoterAddress(e.target.value)}
                  placeholder="Enter your address or area name"
                  className={cn(
                    'mt-2',
                    state.isEasyViewEnabled 
                      ? 'bg-black border-yellow-400 text-yellow-400' 
                      : 'border-civic-blue-300'
                  )}
                />
              </div>

              <Button className={cn(
                'w-full',
                state.isEasyViewEnabled 
                  ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                  : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
              )}>
                <Navigation className="w-4 h-4 mr-2" />
                Find Polling Station
              </Button>

              {voterAddress && (
                <div className={cn(
                  'p-4 rounded-lg border',
                  state.isEasyViewEnabled 
                    ? 'border-yellow-400 bg-yellow-400/20' 
                    : 'border-civic-blue-300 bg-civic-blue-100'
                )}>
                  <h4 className={cn(
                    'font-medium mb-2',
                    state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-800'
                  )}>
                    Your Polling Station (Demo)
                  </h4>
                  <div className="space-y-2">
                    <p className={cn(
                      state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
                    )}>
                      📍 Community Center, Block A, Sector 15
                    </p>
                    <p className={cn(
                      'flex items-center gap-2',
                      state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
                    )}>
                      <Clock className="w-4 h-4" />
                      Open: 7:00 AM - 6:00 PM
                    </p>
                    <p className={cn(
                      'text-sm',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
                    )}>
                      Distance: ~2.5 km from your location
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </Card>
      )}

      {/* Important Reminders */}
      <Card className={cn(
        'p-6 border-2',
        state.isEasyViewEnabled 
          ? 'bg-black border-yellow-400' 
          : 'bg-orange-50 border-orange-200'
      )}>
        <div className="flex items-start gap-3">
          <AlertCircle className={cn(
            'w-6 h-6 mt-1',
            state.isEasyViewEnabled ? 'text-yellow-400' : 'text-orange-600'
          )} />
          <div className="space-y-3">
            <h3 className={cn(
              'font-semibold',
              state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-orange-800'
            )}>
              Important Reminders
            </h3>
            <ul className="space-y-2">
              <li className={cn(
                state.isEasyViewEnabled ? 'text-yellow-300' : 'text-orange-700'
              )}>
                • Voting is completely free - no one should ask for money
              </li>
              <li className={cn(
                state.isEasyViewEnabled ? 'text-yellow-300' : 'text-orange-700'
              )}>
                • Your vote is secret - no one can see who you voted for
              </li>
              <li className={cn(
                state.isEasyViewEnabled ? 'text-yellow-300' : 'text-orange-700'
              )}>
                • You can only vote once - multiple voting is illegal
              </li>
              <li className={cn(
                state.isEasyViewEnabled ? 'text-yellow-300' : 'text-orange-700'
              )}>
                • If you need help, ask the polling officer
              </li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
}
