import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { Settings, Eye, Headphones, Phone } from 'lucide-react';

export default function SettingsPage() {
  const { state, toggleEasyView, toggleAudioHelp } = useAccessibility();

  const handleCall = () => {
    alert('Call Support: 1-800-CIVIC-HELP');
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className={cn(
        'text-center space-y-4 p-8 rounded-2xl relative overflow-hidden',
        state.isEasyViewEnabled
          ? 'bg-black text-yellow-400'
          : 'bg-gradient-to-br from-white/90 to-civic-blue-50/50 backdrop-blur-xl border border-civic-blue-200/30 shadow-2xl shadow-civic-blue-100/20'
      )}>
        <div className="flex items-center justify-center gap-3">
          <Settings className="w-10 h-10 text-civic-blue-600" />
          <h1 className="font-bold text-2xl text-gray-800">
            Settings & Support
          </h1>
        </div>
        <p className="text-base text-gray-600">
          Accessibility settings and support options
        </p>
      </div>

      {/* Audio Settings */}
      <Card className="p-8 border bg-gradient-to-br from-white/90 to-civic-blue-50/30 backdrop-blur-sm border-civic-blue-200/50 shadow-xl shadow-civic-blue-100/20">
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-gradient-to-br from-civic-blue-500 to-civic-blue-600 shadow-lg">
              <Headphones className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold text-lg text-gray-800">
              Audio Settings
            </h3>
          </div>

          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <div className="font-medium text-lg text-gray-700">
                Audio Help Mode
              </div>
              <p className="text-sm text-gray-600">
                Click any element to hear it spoken
              </p>
            </div>
            <Button
              onClick={toggleAudioHelp}
              variant={state.isAudioHelpEnabled ? "default" : "outline"}
              className={cn(
                "px-6 py-3 text-lg font-semibold transition-all duration-300 shadow-lg",
                state.isAudioHelpEnabled
                  ? "bg-gradient-to-r from-civic-green-600 to-civic-green-700 text-white hover:from-civic-green-700 hover:to-civic-green-800 shadow-civic-green-600/40"
                  : "border-civic-blue-300 text-civic-blue-700 hover:bg-civic-blue-50 shadow-civic-blue-200/30"
              )}
            >
              {state.isAudioHelpEnabled ? 'ON' : 'OFF'}
            </Button>
          </div>
        </div>
      </Card>

      {/* Visual Settings */}
      <Card className="p-8 border bg-gradient-to-br from-white/90 to-civic-green-50/30 backdrop-blur-sm border-civic-green-200/50 shadow-xl shadow-civic-green-100/20">
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-gradient-to-br from-civic-green-500 to-civic-green-600 shadow-lg">
              <Eye className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold text-lg text-gray-800">
              Visual Settings
            </h3>
          </div>

          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <div className="font-medium text-lg text-gray-700">
                Easy View Mode
              </div>
              <p className="text-sm text-gray-600">
                Large fonts and high contrast
              </p>
            </div>
            <Button
              onClick={toggleEasyView}
              variant={state.isEasyViewEnabled ? "default" : "outline"}
              className={cn(
                "px-6 py-3 text-lg font-semibold transition-all duration-300 shadow-lg",
                state.isEasyViewEnabled
                  ? "bg-gradient-to-r from-civic-purple-600 to-civic-purple-700 text-white hover:from-civic-purple-700 hover:to-civic-purple-800 shadow-civic-purple-600/40"
                  : "border-civic-green-300 text-civic-green-700 hover:bg-civic-green-50 shadow-civic-green-200/30"
              )}
            >
              {state.isEasyViewEnabled ? 'ON' : 'OFF'}
            </Button>
          </div>
        </div>
      </Card>

      {/* Support */}
      <Card className="p-8 border bg-gradient-to-br from-white/90 to-civic-purple-50/30 backdrop-blur-sm border-civic-purple-200/50 shadow-xl shadow-civic-purple-100/20">
        <div className="space-y-6">
          <h3 className="font-semibold text-lg text-gray-800">
            Get Support
          </h3>

          <div className="grid grid-cols-1 gap-4">
            <Button
              onClick={handleCall}
              className="h-20 flex items-center gap-3 justify-start p-4 bg-gradient-to-r from-civic-blue-600 to-civic-purple-600 text-white shadow-lg hover:shadow-xl hover:from-civic-blue-700 hover:to-civic-purple-700 transition-all duration-300"
            >
              <div className="p-2 rounded-lg bg-white/20">
                <Phone className="w-6 h-6" />
              </div>
              <div className="text-left">
                <div className="font-semibold">Call Support</div>
                <div className="text-sm opacity-90">1-800-CIVIC-HELP</div>
              </div>
            </Button>
          </div>
        </div>
      </Card>

      {/* App Info */}
      <Card className="p-6 border text-center bg-gradient-to-br from-civic-slate-50/80 to-white/60 backdrop-blur-sm border-civic-slate-200/50 shadow-lg">
        <h3 className="font-semibold text-gray-800">
          Civic Connect v1.0
        </h3>
        <p className="text-sm text-gray-600">
          Mobile civic engagement app
        </p>
      </Card>
    </div>
  );
}
