import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { readAloud } from '@/lib/accessibility';
import { 
  MessageSquare,
  ThumbsUp,
  ThumbsDown,
  Volume2,
  CheckCircle,
  FileText,
  Users,
  Calendar,
  Send
} from 'lucide-react';

const policies = [
  {
    id: 1,
    title: 'Improved Street Lighting Initiative',
    category: 'Infrastructure',
    summary: 'Proposal to install LED street lights across all residential areas to improve safety and reduce energy consumption. The project will cover 500+ streets over 6 months.',
    fullDescription: 'This initiative aims to replace all traditional street lights with energy-efficient LED lights. Benefits include 60% reduction in electricity costs, better illumination, and enhanced safety for evening walkers and commuters.',
    deadline: '2024-02-15',
    responses: 245,
    support: 78,
    userFeedback: null
  },
  {
    id: 2,
    title: 'Senior Citizen Healthcare Program',
    category: 'Healthcare',
    summary: 'New healthcare scheme providing free medical checkups, medicines, and home care services for citizens above 65 years of age.',
    fullDescription: 'Comprehensive healthcare program including monthly health checkups, free basic medicines, physiotherapy services at home, and 24/7 medical helpline exclusively for senior citizens.',
    deadline: '2024-02-20',
    responses: 189,
    support: 92,
    userFeedback: 'support'
  },
  {
    id: 3,
    title: 'Community Garden Development',
    category: 'Environment',
    summary: 'Converting unused plots into community gardens where residents can grow vegetables and flowers together, promoting sustainability.',
    fullDescription: 'This project will transform 5 vacant plots into community gardens with individual plots for families, composting areas, tool sharing, and gardening workshops for beginners.',
    deadline: '2024-02-10',
    responses: 156,
    support: 85,
    userFeedback: null
  }
];

export default function PolicyFeedback() {
  const { state } = useAccessibility();
  const [policiesState, setPoliciesState] = useState(policies);
  const [selectedPolicy, setSelectedPolicy] = useState<number | null>(null);
  const [comment, setComment] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);

  const handleReadAloud = (text: string) => {
    readAloud(text);
  };

  const handlePolicyFeedback = (policyId: number, feedback: 'support' | 'oppose') => {
    const updatedPolicies = policiesState.map(policy => {
      if (policy.id === policyId) {
        const actionText = feedback === 'support' ? 'supported' : 'opposed';
        readAloud(`You have ${actionText} the policy: ${policy.title}. Thank you for your feedback.`);
        return { ...policy, userFeedback: feedback };
      }
      return policy;
    });
    setPoliciesState(updatedPolicies);
  };

  const submitDetailedFeedback = () => {
    if (!selectedPolicy || !comment.trim()) {
      readAloud('Please select a policy and write your comment before submitting.');
      return;
    }

    setShowSuccess(true);
    readAloud('Your detailed feedback has been submitted successfully. Thank you for participating in the democratic process.');
    
    setTimeout(() => {
      setShowSuccess(false);
      setComment('');
      setSelectedPolicy(null);
    }, 3000);
  };

  const formatDeadline = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const getDaysLeft = (dateString: string) => {
    const deadline = new Date(dateString);
    const today = new Date();
    const diffTime = deadline.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={cn(
        'text-center space-y-4 p-6 rounded-xl',
        state.isEasyViewEnabled 
          ? 'bg-black text-yellow-400' 
          : 'bg-white border border-civic-blue-200'
      )}>
        <div className="flex items-center justify-center gap-3">
          <MessageSquare className={cn(
            'w-10 h-10',
            state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
          )} />
          <h1 className={cn(
            'font-bold',
            state.isEasyViewEnabled ? 'text-3xl' : 'text-2xl text-gray-800'
          )}>
            Policy Feedback
          </h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleReadAloud('Policy Feedback. Share your thoughts on local policies and government decisions with voice support.')}
            className={cn(
              'h-8 w-8 p-0',
              state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
            )}
          >
            <Volume2 className="w-4 h-4" />
          </Button>
        </div>
        <p className={cn(
          'max-w-2xl mx-auto leading-relaxed',
          state.isEasyViewEnabled ? 'text-xl text-yellow-300' : 'text-gray-600'
        )}>
          Share your thoughts on local policies and government decisions. Your voice matters!
        </p>
      </div>

      {/* Success Message */}
      {showSuccess && (
        <Card className={cn(
          'p-6 text-center border-2',
          state.isEasyViewEnabled 
            ? 'bg-black border-yellow-400' 
            : 'bg-civic-green-50 border-civic-green-300'
        )}>
          <CheckCircle className={cn(
            'w-12 h-12 mx-auto mb-4',
            state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-green-600'
          )} />
          <h3 className={cn(
            'font-semibold mb-2',
            state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-civic-green-800'
          )}>
            Feedback Submitted!
          </h3>
          <p className={cn(
            state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-green-700'
          )}>
            Thank you for participating in the democratic process. Your voice helps shape our community.
          </p>
        </Card>
      )}

      {/* Policy Cards */}
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <h2 className={cn(
            'font-semibold',
            state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
          )}>
            Current Policies for Review
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleReadAloud('Current Policies for Review. Read policy summaries and provide your feedback.')}
            className={cn(
              'h-8 w-8 p-0',
              state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
            )}
          >
            <Volume2 className="w-4 h-4" />
          </Button>
        </div>

        <div className="grid grid-cols-1 gap-6">
          {policiesState.map((policy) => (
            <Card 
              key={policy.id}
              className={cn(
                'p-6 border-2 transition-all duration-300',
                state.isEasyViewEnabled 
                  ? 'bg-black border-yellow-400' 
                  : 'bg-white border-civic-blue-200 hover:border-civic-blue-400 hover:shadow-lg'
              )}
            >
              <div className="space-y-4">
                {/* Policy Header */}
                <div className="flex items-start justify-between">
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-2">
                      <h3 className={cn(
                        'font-semibold leading-tight',
                        state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-gray-800'
                      )}>
                        {policy.title}
                      </h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleReadAloud(`Policy: ${policy.title}. ${policy.summary}`)}
                        className={cn(
                          'h-6 w-6 p-0',
                          state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-500'
                        )}
                      >
                        <Volume2 className="w-3 h-3" />
                      </Button>
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm">
                      <span className={cn(
                        'px-2 py-1 rounded-full font-medium',
                        state.isEasyViewEnabled 
                          ? 'bg-yellow-400/20 text-yellow-400' 
                          : 'bg-civic-blue-100 text-civic-blue-700'
                      )}>
                        {policy.category}
                      </span>
                      
                      <div className={cn(
                        'flex items-center gap-1',
                        state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                      )}>
                        <Calendar className="w-4 h-4" />
                        <span>Deadline: {formatDeadline(policy.deadline)}</span>
                      </div>
                      
                      <div className={cn(
                        'flex items-center gap-1',
                        getDaysLeft(policy.deadline) <= 3 
                          ? 'text-red-500' 
                          : (state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600')
                      )}>
                        <span>
                          {getDaysLeft(policy.deadline) > 0 
                            ? `${getDaysLeft(policy.deadline)} days left`
                            : 'Deadline passed'
                          }
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Policy Summary */}
                <p className={cn(
                  'leading-relaxed',
                  state.isEasyViewEnabled ? 'text-lg text-yellow-300' : 'text-gray-600'
                )}>
                  {policy.summary}
                </p>

                {/* Detailed Description */}
                <div className={cn(
                  'p-4 rounded-lg',
                  state.isEasyViewEnabled 
                    ? 'bg-yellow-400/10 border border-yellow-400' 
                    : 'bg-civic-blue-50 border border-civic-blue-200'
                )}>
                  <div className="flex items-center gap-2 mb-2">
                    <FileText className={cn(
                      'w-4 h-4',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
                    )} />
                    <span className={cn(
                      'font-medium text-sm',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-800'
                    )}>
                      Detailed Information
                    </span>
                  </div>
                  <p className={cn(
                    'text-sm leading-relaxed',
                    state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
                  )}>
                    {policy.fullDescription}
                  </p>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-4">
                  <div className={cn(
                    'text-center p-3 rounded-lg',
                    state.isEasyViewEnabled 
                      ? 'bg-yellow-400/20' 
                      : 'bg-gray-50'
                  )}>
                    <div className={cn(
                      'flex items-center justify-center gap-1 mb-1',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-600'
                    )}>
                      <Users className="w-4 h-4" />
                      <span className="text-sm">Total Responses</span>
                    </div>
                    <div className={cn(
                      'text-2xl font-bold',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-800'
                    )}>
                      {policy.responses}
                    </div>
                  </div>
                  
                  <div className={cn(
                    'text-center p-3 rounded-lg',
                    state.isEasyViewEnabled 
                      ? 'bg-yellow-400/20' 
                      : 'bg-green-50'
                  )}>
                    <div className={cn(
                      'flex items-center justify-center gap-1 mb-1',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-green-600'
                    )}>
                      <ThumbsUp className="w-4 h-4" />
                      <span className="text-sm">Support Rate</span>
                    </div>
                    <div className={cn(
                      'text-2xl font-bold',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-green-600'
                    )}>
                      {policy.support}%
                    </div>
                  </div>
                </div>

                {/* Feedback Buttons */}
                <div className="space-y-3">
                  {policy.userFeedback ? (
                    <div className={cn(
                      'text-center p-3 rounded-lg',
                      policy.userFeedback === 'support'
                        ? (state.isEasyViewEnabled ? 'bg-yellow-400/20 border border-yellow-400' : 'bg-green-100 border border-green-300')
                        : (state.isEasyViewEnabled ? 'bg-red-400/20 border border-red-400' : 'bg-red-100 border border-red-300')
                    )}>
                      <CheckCircle className={cn(
                        'w-6 h-6 mx-auto mb-2',
                        policy.userFeedback === 'support'
                          ? (state.isEasyViewEnabled ? 'text-yellow-400' : 'text-green-600')
                          : (state.isEasyViewEnabled ? 'text-red-400' : 'text-red-600')
                      )} />
                      <p className={cn(
                        'font-medium',
                        policy.userFeedback === 'support'
                          ? (state.isEasyViewEnabled ? 'text-yellow-400' : 'text-green-800')
                          : (state.isEasyViewEnabled ? 'text-red-400' : 'text-red-800')
                      )}>
                        You {policy.userFeedback === 'support' ? 'supported' : 'opposed'} this policy
                      </p>
                    </div>
                  ) : (
                    <div className="flex gap-3">
                      <Button
                        onClick={() => handlePolicyFeedback(policy.id, 'support')}
                        className={cn(
                          'flex-1 flex items-center gap-2 transition-all duration-300',
                          state.isEasyViewEnabled 
                            ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                            : 'bg-civic-green-600 text-white hover:bg-civic-green-700'
                        )}
                      >
                        <ThumbsUp className="w-5 h-5" />
                        Support This Policy
                      </Button>
                      
                      <Button
                        onClick={() => handlePolicyFeedback(policy.id, 'oppose')}
                        variant="outline"
                        className={cn(
                          'flex-1 flex items-center gap-2',
                          state.isEasyViewEnabled 
                            ? 'border-red-400 text-red-400 hover:bg-red-400/20' 
                            : 'border-red-300 text-red-600 hover:bg-red-50'
                        )}
                      >
                        <ThumbsDown className="w-5 h-5" />
                        Oppose This Policy
                      </Button>
                    </div>
                  )}

                  {/* Detailed Feedback Option */}
                  <Button
                    onClick={() => setSelectedPolicy(selectedPolicy === policy.id ? null : policy.id)}
                    variant="outline"
                    className={cn(
                      'w-full flex items-center gap-2',
                      state.isEasyViewEnabled 
                        ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                        : 'border-civic-blue-300 text-civic-blue-600'
                    )}
                  >
                    <MessageSquare className="w-4 h-4" />
                    {selectedPolicy === policy.id ? 'Cancel Detailed Feedback' : 'Provide Detailed Feedback'}
                  </Button>
                </div>

                {/* Detailed Feedback Form */}
                {selectedPolicy === policy.id && (
                  <div className={cn(
                    'p-4 rounded-lg border space-y-4',
                    state.isEasyViewEnabled 
                      ? 'border-yellow-400 bg-yellow-400/10' 
                      : 'border-civic-blue-200 bg-civic-blue-50'
                  )}>
                    <h4 className={cn(
                      'font-medium',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-800'
                    )}>
                      Share Your Detailed Thoughts
                    </h4>
                    
                    <Textarea
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="Write your detailed comments, suggestions, or concerns about this policy..."
                      rows={4}
                      className={cn(
                        state.isEasyViewEnabled 
                          ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600' 
                          : 'border-civic-blue-300'
                      )}
                    />
                    
                    <Button
                      onClick={submitDetailedFeedback}
                      disabled={!comment.trim()}
                      className={cn(
                        'w-full flex items-center gap-2',
                        state.isEasyViewEnabled 
                          ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                          : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
                      )}
                    >
                      <Send className="w-4 h-4" />
                      Submit Detailed Feedback
                    </Button>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* How It Works */}
      <Card className={cn(
        'p-6 border-2',
        state.isEasyViewEnabled 
          ? 'bg-black border-yellow-400' 
          : 'bg-civic-blue-50 border-civic-blue-200'
      )}>
        <div className="space-y-4">
          <h3 className={cn(
            'font-semibold flex items-center gap-2',
            state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-civic-blue-800'
          )}>
            How Policy Feedback Works
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleReadAloud('How Policy Feedback Works. Your feedback is collected and shared with policy makers to help them make informed decisions.')}
              className={cn(
                'h-6 w-6 p-0',
                state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
              )}
            >
              <Volume2 className="w-3 h-3" />
            </Button>
          </h3>
          
          <ul className="space-y-2">
            <li className={cn(
              'flex items-start gap-2',
              state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
            )}>
              <span className="font-bold">1.</span>
              <span>Review policy summaries and detailed information</span>
            </li>
            <li className={cn(
              'flex items-start gap-2',
              state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
            )}>
              <span className="font-bold">2.</span>
              <span>Choose to support or oppose each policy</span>
            </li>
            <li className={cn(
              'flex items-start gap-2',
              state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
            )}>
              <span className="font-bold">3.</span>
              <span>Optionally provide detailed comments and suggestions</span>
            </li>
            <li className={cn(
              'flex items-start gap-2',
              state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
            )}>
              <span className="font-bold">4.</span>
              <span>Your feedback is shared with policy makers anonymously</span>
            </li>
          </ul>
        </div>
      </Card>
    </div>
  );
}
