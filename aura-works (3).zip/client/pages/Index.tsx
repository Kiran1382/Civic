import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Index() {
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect to login page on app entry
    navigate('/login');
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-civic-blue-50 to-civic-green-50">
      <div className="text-center">
        <h1 className="text-2xl font-semibold text-civic-blue-800 flex items-center justify-center gap-3">
          <svg
            className="animate-spin h-8 w-8 text-civic-blue-400"
            viewBox="0 0 50 50"
          >
            <circle
              className="opacity-30"
              cx="25"
              cy="25"
              r="20"
              stroke="currentColor"
              strokeWidth="5"
              fill="none"
            />
            <circle
              className="text-civic-blue-600"
              cx="25"
              cy="25"
              r="20"
              stroke="currentColor"
              strokeWidth="5"
              fill="none"
              strokeDasharray="100"
              strokeDashoffset="75"
            />
          </svg>
          Loading Civic Connect...
        </h1>
        <p className="mt-4 text-civic-blue-700 max-w-md">
          Redirecting to login...
        </p>
      </div>
    </div>
  );
}
