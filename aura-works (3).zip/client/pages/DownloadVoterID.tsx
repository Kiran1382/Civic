import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { readAloud } from '@/lib/accessibility';
import { 
  Download,
  Volume2,
  CheckCircle,
  FileText,
  Shield,
  Smartphone,
  CreditCard,
  Mic,
  Phone
} from 'lucide-react';

export default function DownloadVoterID() {
  const { state } = useAccessibility();
  const [step, setStep] = useState<'details' | 'otp' | 'download'>('details');
  const [voterDetails, setVoterDetails] = useState({
    epicNumber: '',
    phoneNumber: '',
    dateOfBirth: ''
  });
  const [otp, setOtp] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<any>({});

  const handleReadAloud = (text: string) => {
    readAloud(text);
  };

  const handleVoiceInput = (field: string) => {
    readAloud(`Voice input for ${field}. Speak clearly.`);
    // Simulate voice input
    setTimeout(() => {
      if (field === 'epicNumber') {
        setVoterDetails(prev => ({ ...prev, epicNumber: 'ABC1234567' }));
        readAloud('EPIC number recorded: ABC1234567');
      } else if (field === 'phoneNumber') {
        setVoterDetails(prev => ({ ...prev, phoneNumber: '9876543210' }));
        readAloud('Phone number recorded: 9876543210');
      }
    }, 2000);
  };

  const validateDetails = () => {
    const newErrors: any = {};
    if (!voterDetails.epicNumber) newErrors.epicNumber = 'EPIC number is required';
    if (!voterDetails.phoneNumber) newErrors.phoneNumber = 'Phone number is required';
    if (!voterDetails.dateOfBirth) newErrors.dateOfBirth = 'Date of birth is required';
    
    setErrors(newErrors);
    
    if (Object.keys(newErrors).length > 0) {
      const errorFields = Object.keys(newErrors).join(', ');
      readAloud(`Please fill in the required fields: ${errorFields}`);
      return false;
    }
    return true;
  };

  const handleSendOTP = () => {
    if (!validateDetails()) return;
    
    setIsLoading(true);
    readAloud('Sending OTP to your registered mobile number...');
    
    setTimeout(() => {
      setIsLoading(false);
      setStep('otp');
      readAloud('OTP has been sent to your mobile number. Please enter the 6-digit code.');
    }, 2000);
  };

  const handleVerifyOTP = () => {
    if (otp.length < 6) {
      readAloud('Please enter the complete 6-digit OTP');
      return;
    }

    setIsLoading(true);
    readAloud('Verifying OTP...');
    
    setTimeout(() => {
      setIsLoading(false);
      setStep('download');
      readAloud('OTP verified successfully! Your voter ID is ready for download.');
    }, 1500);
  };

  const handleDownload = (format: 'pdf' | 'image') => {
    readAloud(`Downloading voter ID as ${format}. The download will start shortly.`);
    // Simulate download
    setTimeout(() => {
      readAloud('Download completed successfully!');
    }, 1000);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={cn(
        'text-center space-y-4 p-6 rounded-xl',
        state.isEasyViewEnabled 
          ? 'bg-black text-yellow-400' 
          : 'bg-white border border-civic-blue-200'
      )}>
        <div className="flex items-center justify-center gap-3">
          <Download className={cn(
            'w-10 h-10',
            state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
          )} />
          <h1 className={cn(
            'font-bold',
            state.isEasyViewEnabled ? 'text-3xl' : 'text-2xl text-gray-800'
          )}>
            Download Voter ID
          </h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleReadAloud('Download Voter ID. Get your digital voter ID card with OTP verification and accessibility features.')}
            className={cn(
              'h-8 w-8 p-0',
              state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
            )}
          >
            <Volume2 className="w-4 h-4" />
          </Button>
        </div>
        <p className={cn(
          'max-w-2xl mx-auto leading-relaxed',
          state.isEasyViewEnabled ? 'text-xl text-yellow-300' : 'text-gray-600'
        )}>
          Get your digital voter ID card with OTP verification and full accessibility features
        </p>
      </div>

      {/* Progress Steps */}
      <div className="flex justify-center space-x-4">
        {['details', 'otp', 'download'].map((stepName, index) => (
          <div key={stepName} className="flex items-center">
            <div className={cn(
              'w-10 h-10 rounded-full flex items-center justify-center font-bold',
              step === stepName || (index === 0 && (step === 'otp' || step === 'download')) || (index === 1 && step === 'download')
                ? (state.isEasyViewEnabled ? 'bg-yellow-400 text-black' : 'bg-civic-blue-500 text-white')
                : (state.isEasyViewEnabled ? 'bg-yellow-800 text-yellow-400' : 'bg-gray-300 text-gray-600')
            )}>
              {index + 1}
            </div>
            {index < 2 && (
              <div className={cn(
                'w-16 h-1 mx-2',
                (step === 'otp' && index === 0) || (step === 'download' && index <= 1)
                  ? (state.isEasyViewEnabled ? 'bg-yellow-400' : 'bg-civic-blue-500')
                  : (state.isEasyViewEnabled ? 'bg-yellow-800' : 'bg-gray-300')
              )} />
            )}
          </div>
        ))}
      </div>

      {/* Step Content */}
      <div className="max-w-2xl mx-auto">
        {/* Step 1: Enter Details */}
        {step === 'details' && (
          <Card className={cn(
            'p-8 border-2',
            state.isEasyViewEnabled 
              ? 'bg-black border-yellow-400' 
              : 'bg-white border-civic-blue-200 shadow-xl'
          )}>
            <div className="space-y-6">
              <div className="text-center space-y-2">
                <CreditCard className={cn(
                  'w-12 h-12 mx-auto',
                  state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
                )} />
                <h2 className={cn(
                  'font-semibold',
                  state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
                )}>
                  Enter Your Details
                </h2>
                <p className={cn(
                  state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                )}>
                  Please provide your voter details to download your ID card
                </p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className={cn(
                    'font-medium flex items-center gap-2',
                    state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                  )}>
                    EPIC Number (Voter ID Number) *
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleReadAloud('EPIC Number field. Enter your voter ID card number.')}
                      className={cn(
                        'h-5 w-5 p-0',
                        state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-500'
                      )}
                    >
                      <Volume2 className="w-3 h-3" />
                    </Button>
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      value={voterDetails.epicNumber}
                      onChange={(e) => setVoterDetails(prev => ({ ...prev, epicNumber: e.target.value.toUpperCase() }))}
                      placeholder="Enter EPIC number (e.g., ABC1234567)"
                      className={cn(
                        'flex-1 uppercase',
                        errors.epicNumber && 'border-red-500',
                        state.isEasyViewEnabled 
                          ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                          : 'border-civic-blue-300'
                      )}
                      maxLength={10}
                    />
                    <Button
                      onClick={() => handleVoiceInput('epicNumber')}
                      variant="outline"
                      size="icon"
                      className={cn(
                        state.isEasyViewEnabled 
                          ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                          : 'border-civic-blue-300 text-civic-blue-600'
                      )}
                    >
                      <Mic className="w-4 h-4" />
                    </Button>
                  </div>
                  {errors.epicNumber && (
                    <p className="text-red-500 text-sm">{errors.epicNumber}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label className={cn(
                    'font-medium flex items-center gap-2',
                    state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                  )}>
                    Registered Mobile Number *
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      type="tel"
                      value={voterDetails.phoneNumber}
                      onChange={(e) => setVoterDetails(prev => ({ ...prev, phoneNumber: e.target.value.replace(/\D/g, '').slice(0, 10) }))}
                      placeholder="Enter 10-digit mobile number"
                      className={cn(
                        'flex-1',
                        errors.phoneNumber && 'border-red-500',
                        state.isEasyViewEnabled 
                          ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600 text-lg' 
                          : 'border-civic-blue-300'
                      )}
                      maxLength={10}
                    />
                    <Button
                      onClick={() => handleVoiceInput('phoneNumber')}
                      variant="outline"
                      size="icon"
                      className={cn(
                        state.isEasyViewEnabled 
                          ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                          : 'border-civic-blue-300 text-civic-blue-600'
                      )}
                    >
                      <Mic className="w-4 h-4" />
                    </Button>
                  </div>
                  {errors.phoneNumber && (
                    <p className="text-red-500 text-sm">{errors.phoneNumber}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label className={cn(
                    'font-medium',
                    state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                  )}>
                    Date of Birth *
                  </Label>
                  <Input
                    type="date"
                    value={voterDetails.dateOfBirth}
                    onChange={(e) => setVoterDetails(prev => ({ ...prev, dateOfBirth: e.target.value }))}
                    className={cn(
                      errors.dateOfBirth && 'border-red-500',
                      state.isEasyViewEnabled 
                        ? 'bg-black border-yellow-400 text-yellow-400 text-lg' 
                        : 'border-civic-blue-300'
                    )}
                  />
                  {errors.dateOfBirth && (
                    <p className="text-red-500 text-sm">{errors.dateOfBirth}</p>
                  )}
                </div>
              </div>

              <Button
                onClick={handleSendOTP}
                disabled={isLoading}
                className={cn(
                  'w-full transition-all duration-300',
                  state.isEasyViewEnabled 
                    ? 'bg-yellow-400 text-black hover:bg-yellow-500 text-lg py-6' 
                    : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700 py-3'
                )}
              >
                {isLoading ? 'Sending OTP...' : 'Send OTP'}
              </Button>
            </div>
          </Card>
        )}

        {/* Step 2: OTP Verification */}
        {step === 'otp' && (
          <Card className={cn(
            'p-8 border-2',
            state.isEasyViewEnabled 
              ? 'bg-black border-yellow-400' 
              : 'bg-white border-civic-blue-200 shadow-xl'
          )}>
            <div className="space-y-6">
              <div className="text-center space-y-2">
                <Smartphone className={cn(
                  'w-12 h-12 mx-auto',
                  state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
                )} />
                <h2 className={cn(
                  'font-semibold',
                  state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
                )}>
                  Verify OTP
                </h2>
                <p className={cn(
                  state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                )}>
                  Enter the 6-digit code sent to {voterDetails.phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, '$1-***-$3')}
                </p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className={cn(
                    'font-medium text-center block',
                    state.isEasyViewEnabled ? 'text-lg text-yellow-400' : 'text-gray-700'
                  )}>
                    Enter OTP
                  </Label>
                  <Input
                    type="text"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    placeholder="Enter 6-digit OTP"
                    className={cn(
                      'text-center tracking-wider text-2xl font-mono',
                      state.isEasyViewEnabled 
                        ? 'bg-black border-yellow-400 text-yellow-400 placeholder:text-yellow-600' 
                        : 'border-civic-blue-300'
                    )}
                    maxLength={6}
                  />
                </div>

                <Button
                  onClick={handleVerifyOTP}
                  disabled={isLoading || otp.length < 6}
                  className={cn(
                    'w-full transition-all duration-300',
                    state.isEasyViewEnabled 
                      ? 'bg-yellow-400 text-black hover:bg-yellow-500 text-lg py-6' 
                      : 'bg-civic-green-600 text-white hover:bg-civic-green-700 py-3'
                  )}
                >
                  {isLoading ? 'Verifying...' : 'Verify OTP'}
                </Button>

                <div className="text-center">
                  <Button
                    variant="link"
                    onClick={handleSendOTP}
                    className={cn(
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
                    )}
                  >
                    Didn't receive OTP? Resend
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Step 3: Download */}
        {step === 'download' && (
          <Card className={cn(
            'p-8 border-2',
            state.isEasyViewEnabled 
              ? 'bg-black border-yellow-400' 
              : 'bg-white border-civic-green-200 shadow-xl'
          )}>
            <div className="space-y-6">
              <div className="text-center space-y-4">
                <CheckCircle className={cn(
                  'w-16 h-16 mx-auto',
                  state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-green-600'
                )} />
                <h2 className={cn(
                  'font-semibold',
                  state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
                )}>
                  Verification Successful!
                </h2>
                <p className={cn(
                  state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                )}>
                  Your voter ID is ready for download
                </p>
              </div>

              {/* Voter ID Preview */}
              <Card className={cn(
                'p-6 border-2',
                state.isEasyViewEnabled 
                  ? 'bg-yellow-400/10 border-yellow-400' 
                  : 'bg-civic-blue-50 border-civic-blue-200'
              )}>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Shield className={cn(
                      'w-5 h-5',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-600'
                    )} />
                    <h3 className={cn(
                      'font-semibold',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-civic-blue-800'
                    )}>
                      Voter ID Details
                    </h3>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className={cn(
                        'font-medium',
                        state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-700'
                      )}>
                        EPIC No:
                      </span>
                      <p className={cn(
                        'font-mono',
                        state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                      )}>
                        {voterDetails.epicNumber}
                      </p>
                    </div>
                    <div>
                      <span className={cn(
                        'font-medium',
                        state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-700'
                      )}>
                        Name:
                      </span>
                      <p className={cn(
                        state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                      )}>
                        Rajesh Kumar Singh
                      </p>
                    </div>
                    <div>
                      <span className={cn(
                        'font-medium',
                        state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-700'
                      )}>
                        Assembly Constituency:
                      </span>
                      <p className={cn(
                        state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                      )}>
                        05 - Central Delhi
                      </p>
                    </div>
                    <div>
                      <span className={cn(
                        'font-medium',
                        state.isEasyViewEnabled ? 'text-yellow-400' : 'text-gray-700'
                      )}>
                        Part No:
                      </span>
                      <p className={cn(
                        state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-600'
                      )}>
                        123
                      </p>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Download Options */}
              <div className="space-y-4">
                <h3 className={cn(
                  'font-semibold text-center',
                  state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-gray-800'
                )}>
                  Choose Download Format
                </h3>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Button
                    onClick={() => handleDownload('pdf')}
                    className={cn(
                      'h-16 flex flex-col gap-2',
                      state.isEasyViewEnabled 
                        ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                        : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
                    )}
                  >
                    <FileText className="w-6 h-6" />
                    <span>Download as PDF</span>
                  </Button>
                  
                  <Button
                    onClick={() => handleDownload('image')}
                    variant="outline"
                    className={cn(
                      'h-16 flex flex-col gap-2',
                      state.isEasyViewEnabled 
                        ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20' 
                        : 'border-civic-blue-300 text-civic-blue-600'
                    )}
                  >
                    <Download className="w-6 h-6" />
                    <span>Download as Image</span>
                  </Button>
                </div>
              </div>

              <Card className={cn(
                'p-4 border',
                state.isEasyViewEnabled 
                  ? 'border-yellow-400 bg-yellow-400/10' 
                  : 'border-blue-200 bg-blue-50'
              )}>
                <div className="flex items-start gap-3">
                  <Shield className={cn(
                    'w-5 h-5 mt-1',
                    state.isEasyViewEnabled ? 'text-yellow-400' : 'text-blue-600'
                  )} />
                  <div className="text-sm">
                    <h4 className={cn(
                      'font-medium mb-1',
                      state.isEasyViewEnabled ? 'text-yellow-400' : 'text-blue-800'
                    )}>
                      Digital Voter ID is Legally Valid
                    </h4>
                    <p className={cn(
                      state.isEasyViewEnabled ? 'text-yellow-300' : 'text-blue-700'
                    )}>
                      This digital voter ID card is legally valid for all voting purposes and can be used as proof of identity.
                    </p>
                  </div>
                </div>
              </Card>
            </div>
          </Card>
        )}
      </div>

      {/* Help Section */}
      <Card className={cn(
        'p-6 border-2',
        state.isEasyViewEnabled 
          ? 'bg-black border-yellow-400' 
          : 'bg-civic-blue-50 border-civic-blue-200'
      )}>
        <div className="space-y-4">
          <h3 className={cn(
            'font-semibold',
            state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-civic-blue-800'
          )}>
            Need Help?
          </h3>
          <p className={cn(
            state.isEasyViewEnabled ? 'text-yellow-300' : 'text-civic-blue-700'
          )}>
            Use voice input for easy form filling, or contact our support team for assistance with voter ID downloads.
          </p>
          <Button className={cn(
            'flex items-center gap-2',
            state.isEasyViewEnabled 
              ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
              : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
          )}>
            <Phone className="w-4 h-4" />
            Call Support: 1800-XXX-XXXX
          </Button>
        </div>
      </Card>
    </div>
  );
}
