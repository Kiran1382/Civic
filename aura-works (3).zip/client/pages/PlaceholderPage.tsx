import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { readAloud } from '@/lib/accessibility';
import { Link } from 'react-router-dom';
import { 
  Construction,
  ArrowLeft,
  Volume2,
  MessageCircle
} from 'lucide-react';

interface PlaceholderPageProps {
  title: string;
  description: string;
  icon?: React.ReactNode;
}

export default function PlaceholderPage({ 
  title, 
  description, 
  icon = <Construction className="w-12 h-12" /> 
}: PlaceholderPageProps) {
  const { state } = useAccessibility();

  const handleReadAloud = (text: string) => {
    readAloud(text);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className={cn(
        'w-full max-w-2xl p-8 text-center space-y-6 border-2',
        state.isEasyViewEnabled 
          ? 'bg-black border-yellow-400' 
          : 'bg-white border-civic-blue-200 shadow-xl'
      )}>
        {/* Icon */}
        <div className={cn(
          'w-20 h-20 mx-auto rounded-full flex items-center justify-center',
          state.isEasyViewEnabled 
            ? 'bg-yellow-400 text-black' 
            : 'bg-civic-blue-100 text-civic-blue-600'
        )}>
          {icon}
        </div>

        {/* Title */}
        <div className="space-y-3">
          <div className="flex items-center justify-center gap-3">
            <h1 className={cn(
              'font-bold',
              state.isEasyViewEnabled ? 'text-3xl text-yellow-400' : 'text-2xl text-gray-800'
            )}>
              {title}
            </h1>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleReadAloud(`${title}. ${description}`)}
              className={cn(
                'h-8 w-8 p-0',
                state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-blue-600'
              )}
              aria-label={`Read about ${title}`}
            >
              <Volume2 className="w-4 h-4" />
            </Button>
          </div>
          
          <p className={cn(
            'max-w-lg mx-auto leading-relaxed',
            state.isEasyViewEnabled ? 'text-xl text-yellow-300' : 'text-lg text-gray-600'
          )}>
            {description}
          </p>
        </div>

        {/* Coming Soon Message */}
        <Card className={cn(
          'p-6 border-2',
          state.isEasyViewEnabled 
            ? 'bg-black border-yellow-400' 
            : 'bg-civic-green-50 border-civic-green-200'
        )}>
          <div className="space-y-4">
            <div className="flex items-center justify-center gap-3">
              <h2 className={cn(
                'font-semibold',
                state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-civic-green-800'
              )}>
                Coming Soon!
              </h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleReadAloud('Coming Soon! This feature is being developed. Please check back later or contact support for assistance.')}
                className={cn(
                  'h-6 w-6 p-0',
                  state.isEasyViewEnabled ? 'text-yellow-400 hover:bg-yellow-400/20' : 'text-civic-green-600'
                )}
                aria-label="Read coming soon message"
              >
                <Volume2 className="w-3 h-3" />
              </Button>
            </div>
            <p className={cn(
              'leading-relaxed',
              state.isEasyViewEnabled ? 'text-lg text-yellow-300' : 'text-civic-green-700'
            )}>
              This feature is being developed to serve you better. 
              Please check back later or contact support for assistance.
            </p>
          </div>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/dashboard">
            <Button className={cn(
              'flex items-center gap-2 transition-all duration-300',
              state.isEasyViewEnabled 
                ? 'bg-yellow-400 text-black hover:bg-yellow-500 text-lg px-8 py-4' 
                : 'bg-civic-blue-600 text-white hover:bg-civic-blue-700'
            )}>
              <ArrowLeft className="w-5 h-5" />
              Back to Dashboard
            </Button>
          </Link>
          
          <Link to="/settings">
            <Button 
              variant="outline"
              className={cn(
                'flex items-center gap-2',
                state.isEasyViewEnabled 
                  ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20 text-lg px-8 py-4' 
                  : 'border-civic-green-300 text-civic-green-600'
              )}
            >
              <MessageCircle className="w-5 h-5" />
              Contact Support
            </Button>
          </Link>
        </div>

        {/* Help Text */}
        <p className={cn(
          'text-sm opacity-75',
          state.isEasyViewEnabled ? 'text-yellow-300' : 'text-gray-500'
        )}>
          Use the microphone button at the bottom for voice commands
        </p>
      </Card>
    </div>
  );
}
