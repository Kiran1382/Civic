import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { readAloud, handleTouchToRead } from '@/lib/accessibility';
import {
  Vote,
  AlertTriangle,
  Calendar,
  MessageSquare,
  Newspaper,
  FileText,
  UserPlus,
  Download,
  Volume2,
  Settings
} from 'lucide-react';

interface NavigationCard {
  title: string;
  description: string;
  icon: React.ReactNode;
  href: string;
  color: string;
}

const navigationCards: NavigationCard[] = [
  {
    title: "Voting Help",
    description: "Learn how to vote, find your polling booth, and practice with sample ballots",
    icon: <Vote className="w-8 h-8" />,
    href: "/voting-guidance",
    color: "civic-blue"
  },
  {
    title: "Report Local Issue",
    description: "Report problems in your community with photos and location",
    icon: <AlertTriangle className="w-8 h-8" />,
    href: "/report-issue",
    color: "civic-green"
  },
  {
    title: "Community Events",
    description: "Find local events, meetings, and community activities",
    icon: <Calendar className="w-8 h-8" />,
    href: "/events",
    color: "civic-blue"
  },
  {
    title: "Policy Feedback",
    description: "Share your thoughts on local policies and government decisions",
    icon: <MessageSquare className="w-8 h-8" />,
    href: "/policy-feedback",
    color: "civic-green"
  },
  {
    title: "Government News",
    description: "Stay updated with latest news and announcements",
    icon: <Newspaper className="w-8 h-8" />,
    href: "/news",
    color: "civic-blue"
  },
  {
    title: "New Voter Registration",
    description: "Register as a new voter with step-by-step guidance and document upload",
    icon: <UserPlus className="w-8 h-8" />,
    href: "/voter-registration",
    color: "civic-green"
  },
  {
    title: "Download Voter ID",
    description: "Get your digital voter ID card with OTP verification",
    icon: <Download className="w-8 h-8" />,
    href: "/download-voter-id",
    color: "civic-blue"
  }
];

const quickActions = [
  {
    title: "Emergency Support",
    description: "Call for urgent assistance",
    icon: <FileText className="w-6 h-6" />,
    href: "tel:108"
  }
];

export default function Dashboard() {
  const { state } = useAccessibility();

  const handleCardClick = (title: string, description: string) => {
    if (state.isTouchToReadEnabled) {
      readAloud(`${title}. ${description}`);
    }
  };

  const handleReadAloud = (text: string) => {
    readAloud(text);
  };

  return (
    <div className="space-y-4 sm:space-y-6 lg:space-y-8">
      {/* Welcome Section */}
      <div className={cn(
        'text-center space-y-4 p-8 rounded-2xl relative overflow-hidden',
        state.isEasyViewEnabled
          ? 'bg-black text-yellow-400'
          : 'bg-gradient-to-br from-white/80 to-civic-blue-50/50 backdrop-blur-xl border border-civic-blue-200/30 shadow-2xl shadow-civic-blue-100/20'
      )}>
        <h1 className={cn(
          'font-bold text-center',
          state.isEasyViewEnabled ? 'text-3xl' : 'text-2xl text-gray-800'
        )}>
          Welcome to Civic Connect
        </h1>
        <p className={cn(
          'max-w-2xl mx-auto leading-relaxed',
          state.isEasyViewEnabled ? 'text-xl text-yellow-300' : 'text-gray-600'
        )}>
          Your gateway to community participation and government services. 
          Choose from the options below to get started.
        </p>
      </div>

      {/* Main Navigation Grid */}
      <div className="space-y-6">
        <h2 className={cn(
          'font-semibold',
          state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
        )}>
          Main Services
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {navigationCards.map((card, index) => (
            <Card
              key={index}
              className={cn(
                'p-6 transition-all duration-500 hover:scale-105 cursor-pointer border group relative overflow-hidden',
                state.isEasyViewEnabled
                  ? 'bg-black border-yellow-400 hover:border-yellow-300'
                  : `bg-gradient-to-br from-white/90 to-${card.color}-50/30 backdrop-blur-sm border-${card.color}-200/50 hover:border-${card.color}-400/70 hover:shadow-2xl hover:shadow-${card.color}-200/20`
              )}
              onClick={() => handleCardClick(card.title, card.description)}
            >
              <Link to={card.href} className="block h-full">
                <div className="flex items-start gap-4 h-full">
                  <div className={cn(
                    'flex-shrink-0 p-4 rounded-xl shadow-lg transition-transform duration-300 group-hover:scale-110',
                    state.isEasyViewEnabled
                      ? 'bg-yellow-400 text-black'
                      : `bg-gradient-to-br from-${card.color}-500 to-${card.color}-600 text-white shadow-${card.color}-500/30`
                  )}>
                    {card.icon}
                  </div>
                  
                  <div className="flex-1 space-y-2">
                    <h3 className={cn(
                      'font-semibold',
                      state.isEasyViewEnabled
                        ? 'text-xl text-yellow-400'
                        : 'text-lg text-gray-800'
                    )}>
                      {card.title}
                    </h3>
                    <p className={cn(
                      'leading-relaxed',
                      state.isEasyViewEnabled 
                        ? 'text-lg text-yellow-300' 
                        : 'text-gray-600'
                    )}>
                      {card.description}
                    </p>
                  </div>
                </div>
              </Link>
            </Card>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="space-y-4">
        <h2 className={cn(
          'font-semibold',
          state.isEasyViewEnabled ? 'text-2xl text-yellow-400' : 'text-xl text-gray-800'
        )}>
          Quick Actions
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {quickActions.map((action, index) => (
            <Card 
              key={index}
              className={cn(
                'p-4 transition-all duration-300 hover:scale-105 cursor-pointer border-2',
                state.isEasyViewEnabled 
                  ? 'bg-black border-yellow-400 hover:border-yellow-300' 
                  : 'border-civic-green-200 hover:border-civic-green-400 bg-white hover:shadow-md'
              )}
              onClick={() => handleCardClick(action.title, action.description)}
            >
              <Link to={action.href} className="block h-full">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    'flex-shrink-0 p-2 rounded-lg',
                    state.isEasyViewEnabled 
                      ? 'bg-yellow-400 text-black' 
                      : 'bg-civic-green-100 text-civic-green-600'
                  )}>
                    {action.icon}
                  </div>
                  
                  <div className="flex-1">
                    <h3 className={cn(
                      'font-semibold',
                      state.isEasyViewEnabled
                        ? 'text-lg text-yellow-400'
                        : 'text-gray-800'
                    )}>
                      {action.title}
                    </h3>
                    <p className={cn(
                      'text-sm',
                      state.isEasyViewEnabled 
                        ? 'text-yellow-300' 
                        : 'text-gray-600'
                    )}>
                      {action.description}
                    </p>
                  </div>
                </div>
              </Link>
            </Card>
          ))}
        </div>
      </div>

      {/* Help Section */}
      <Card className={cn(
        'p-6 text-center border-2',
        state.isEasyViewEnabled 
          ? 'bg-black border-yellow-400' 
          : 'bg-civic-blue-50 border-civic-blue-200'
      )}>
        <div className="space-y-4">
          <h3 className={cn(
            'font-semibold text-center',
            state.isEasyViewEnabled ? 'text-xl text-yellow-400' : 'text-lg text-civic-blue-800'
          )}>
            Need Help?
          </h3>
          <p className={cn(
            'max-w-lg mx-auto',
            state.isEasyViewEnabled ? 'text-lg text-yellow-300' : 'text-civic-blue-700'
          )}>
            Click the microphone button at the bottom for voice commands, 
            or visit settings to customize your experience.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button
              onClick={() => window.location.href = '/settings'}
              className={cn(
                'transition-all duration-300 shadow-lg px-8 py-3',
                state.isEasyViewEnabled
                  ? 'bg-yellow-400 text-black hover:bg-yellow-500 shadow-yellow-400/30'
                  : 'bg-gradient-to-r from-civic-blue-600 to-civic-purple-600 text-white hover:from-civic-blue-700 hover:to-civic-purple-700 shadow-civic-blue-600/40 hover:shadow-xl hover:shadow-civic-blue-600/50'
              )}
            >
              Settings & Support
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
