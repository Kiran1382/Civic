import React, { createContext, useContext, useState, ReactNode } from 'react';
import { AccessibilityState, defaultAccessibilityState } from '@/lib/accessibility';

interface AccessibilityContextType {
  state: AccessibilityState;
  updateState: (updates: Partial<AccessibilityState>) => void;
  toggleEasyView: () => void;
  toggleTouchToRead: () => void;
  toggleVoiceMode: () => void;
  toggleAudioHelp: () => void;
}

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

export const useAccessibility = () => {
  const context = useContext(AccessibilityContext);
  if (!context) {
    throw new Error('useAccessibility must be used within AccessibilityProvider');
  }
  return context;
};

interface AccessibilityProviderProps {
  children: ReactNode;
}

export const AccessibilityProvider: React.FC<AccessibilityProviderProps> = ({ children }) => {
  const [state, setState] = useState<AccessibilityState>(defaultAccessibilityState);

  // Initialize localStorage on mount
  React.useEffect(() => {
    localStorage.setItem('audioHelpEnabled', 'false');
  }, []);

  const updateState = (updates: Partial<AccessibilityState>) => {
    setState(prev => ({ ...prev, ...updates }));
  };

  const toggleEasyView = () => {
    setState(prev => ({ ...prev, isEasyViewEnabled: !prev.isEasyViewEnabled }));
  };

  const toggleTouchToRead = () => {
    setState(prev => ({ ...prev, isTouchToReadEnabled: !prev.isTouchToReadEnabled }));
  };

  const toggleVoiceMode = () => {
    setState(prev => ({ ...prev, isVoiceMode: !prev.isVoiceMode }));
  };

  const toggleAudioHelp = () => {
    setState(prev => {
      const newState = !prev.isAudioHelpEnabled;
      // Sync with localStorage so readAloud function can access it
      localStorage.setItem('audioHelpEnabled', newState.toString());
      return { ...prev, isAudioHelpEnabled: newState };
    });
  };

  return (
    <AccessibilityContext.Provider value={{
      state,
      updateState,
      toggleEasyView,
      toggleTouchToRead,
      toggleVoiceMode,
      toggleAudioHelp,
    }}>
      {children}
    </AccessibilityContext.Provider>
  );
};
