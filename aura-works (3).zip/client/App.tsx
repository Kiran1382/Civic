import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AccessibilityProvider } from "./contexts/AccessibilityContext";
import { AccessibilityLayout } from "./components/AccessibilityLayout";

// Import all pages
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Onboarding from "./pages/Onboarding";
import VotingGuidance from "./pages/VotingGuidance";
import ReportIssue from "./pages/ReportIssue";
import Events from "./pages/Events";
import PolicyFeedback from "./pages/PolicyFeedback";
import News from "./pages/News";
import VoterRegistration from "./pages/VoterRegistration";
import DownloadVoterID from "./pages/DownloadVoterID";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AccessibilityProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Login - Entry point */}
            <Route path="/" element={<AccessibilityLayout title="Login - Civic Connect"><Login /></AccessibilityLayout>} />
            <Route path="/login" element={<AccessibilityLayout title="Login - Civic Connect"><Login /></AccessibilityLayout>} />

            {/* Main Dashboard */}
            <Route path="/dashboard" element={<AccessibilityLayout title="Dashboard - Civic Connect"><Dashboard /></AccessibilityLayout>} />

            {/* Onboarding & Language Selection */}
            <Route path="/onboarding" element={<AccessibilityLayout title="Welcome - Civic Connect"><Onboarding /></AccessibilityLayout>} />

            {/* Core Civic Services */}
            <Route path="/voting-guidance" element={<AccessibilityLayout title="Voting Help - Civic Connect"><VotingGuidance /></AccessibilityLayout>} />
            <Route path="/report-issue" element={<AccessibilityLayout title="Report Issue - Civic Connect"><ReportIssue /></AccessibilityLayout>} />
            <Route path="/events" element={<AccessibilityLayout title="Community Events - Civic Connect"><Events /></AccessibilityLayout>} />
            <Route path="/policy-feedback" element={<AccessibilityLayout title="Policy Feedback - Civic Connect"><PolicyFeedback /></AccessibilityLayout>} />
            <Route path="/news" element={<AccessibilityLayout title="Government News - Civic Connect"><News /></AccessibilityLayout>} />

            {/* Voter Services */}
            <Route path="/voter-registration" element={<AccessibilityLayout title="Voter Registration - Civic Connect"><VoterRegistration /></AccessibilityLayout>} />
            <Route path="/download-voter-id" element={<AccessibilityLayout title="Download Voter ID - Civic Connect"><DownloadVoterID /></AccessibilityLayout>} />

            {/* Settings & Support */}
            <Route path="/settings" element={<AccessibilityLayout title="Settings - Civic Connect"><Settings /></AccessibilityLayout>} />

            {/* 404 Page */}
            <Route path="*" element={<AccessibilityLayout title="Page Not Found - Civic Connect"><NotFound /></AccessibilityLayout>} />
          </Routes>
        </BrowserRouter>
      </AccessibilityProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
