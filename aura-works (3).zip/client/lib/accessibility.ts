// Global accessibility functions for civic engagement app

export interface AccessibilityState {
  isEasyViewEnabled: boolean;
  isTouchToReadEnabled: boolean;
  isVoiceMode: boolean;
  isAudioHelpEnabled: boolean;
  speechSpeed: number;
  fontSize: number;
}

export const defaultAccessibilityState: AccessibilityState = {
  isEasyViewEnabled: false,
  isTouchToReadEnabled: false,
  isVoiceMode: false,
  isAudioHelpEnabled: false,
  speechSpeed: 1,
  fontSize: 16,
};

// Text-to-Speech function - with global audio help check
export const readAloud = (text: string, forceRead: boolean = false): void => {
  console.log('🔊 Reading aloud:', text);

  // Check global audio help state from localStorage (since we can't access React context here)
  const audioHelpEnabled = localStorage.getItem('audioHelpEnabled') === 'true';

  // Only read if audio help is enabled OR if explicitly forced (like for explicit button clicks)
  if (!audioHelpEnabled && !forceRead) {
    console.log('🔇 Audio Help is OFF - not reading');
    return;
  }

  // Check if browser supports Speech Synthesis
  if ('speechSynthesis' in window) {
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.8; // Slower rate for seniors
    utterance.pitch = 1;
    utterance.volume = 1;

    // Prefer a clear voice if available
    const voices = window.speechSynthesis.getVoices();
    const englishVoice = voices.find(voice => voice.lang.includes('en-')) || voices[0];
    if (englishVoice) {
      utterance.voice = englishVoice;
    }

    window.speechSynthesis.speak(utterance);
  } else {
    // Fallback for browsers without speech synthesis
    alert(`Reading: ${text}`);
  }
};

// Voice command mock function
export const startVoiceCommand = (): void => {
  console.log('🎤 Voice command activated');
  // This would integrate with Speech Recognition API in a real implementation
  alert('Voice commands:\n• "Open Voting Help"\n• "Show Events"\n• "Find Polling Booth"\n• "Go Home"\n• "Help"');
};

// Easy View mode helper
export const getEasyViewClasses = (isEnabled: boolean): string => {
  return isEnabled 
    ? 'text-2xl bg-black text-yellow-400 contrast-125' 
    : '';
};

// Touch-to-read helper
export const handleTouchToRead = (text: string, isTouchToReadEnabled: boolean): void => {
  if (isTouchToReadEnabled) {
    readAloud(text);
  }
};

// Smart audio help - auto read on focus/click when enabled
export const handleSmartAudioHelp = (text: string, isAudioHelpEnabled: boolean): void => {
  if (isAudioHelpEnabled) {
    readAloud(text);
  }
};

// Long press helper - always reads regardless of mode (explicit user action)
export const handleLongPress = (text: string): void => {
  readAloud(text, true);
};

// Add long press event listeners to an element
export const addLongPressListener = (element: HTMLElement, text: string): void => {
  let pressTimer: NodeJS.Timeout;

  const startPress = () => {
    pressTimer = setTimeout(() => {
      handleLongPress(text);
    }, 800); // 800ms long press
  };

  const endPress = () => {
    clearTimeout(pressTimer);
  };

  element.addEventListener('touchstart', startPress);
  element.addEventListener('touchend', endPress);
  element.addEventListener('mousedown', startPress);
  element.addEventListener('mouseup', endPress);
  element.addEventListener('mouseleave', endPress);
};
